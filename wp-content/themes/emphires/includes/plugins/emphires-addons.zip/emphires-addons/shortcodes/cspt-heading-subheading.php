<?php

if( !function_exists('creativesplanet_sc_heading_subheading') ){
function creativesplanet_sc_heading_subheading( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_heading_subheading_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), 'cspt-heading-subheading', $atts );

		// Preparing heading and subheading
		if( !empty($atts['h2']) ){
			$ih_sc = '[cspt-icon-heading ';
			foreach( $atts as $key=>$val ){
				$ih_sc .= ' ' . $key . '="'.$val.'" ';
			}
			$ih_sc .= ' icon_type="none"]';
			if( !empty($content) ){
				$ih_sc .= $content.'[/cspt-icon-heading]';
			}

			$ih_code = do_shortcode( $ih_sc );
			$return .= str_replace( 'cspt-ihbox-style-1', 'cspt-ihbox-style-hsbox '.$css_class, $ih_code );
		}

	}

	return $return;

}
}
add_shortcode( 'cspt-heading-subheading', 'creativesplanet_sc_heading_subheading' );
