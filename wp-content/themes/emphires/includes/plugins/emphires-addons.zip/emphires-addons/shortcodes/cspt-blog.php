<?php

if( !function_exists('creativesplanet_sc_blog') ){
function creativesplanet_sc_blog( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_blog_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		// Starting container
		$return .= creativesplanet_element_container( array(
			'position'	=> 'start',
			'cpt'		=> 'blog',
			'data'		=> $atts
		) );

			$return .= '<div class="cspt-ele-header-area">';

			// Preparing heading and subheading
			if( !empty($atts['h_h2']) ){
				$ih_sc = '[cspt-icon-heading text="'.$atts['h_h2'].'" ';
				foreach( $atts as $key=>$val ){
					if( substr( $key, 0, 2 ) == 'h_' ){
						$ih_sc .= ' ' . substr( $key, 2 ) . '="'.$val.'" ';
					}
				}
				$ih_sc .= ' icon_type="none"]';

				$ih_code = do_shortcode( $ih_sc );
				$return .= str_replace( 'cspt-ihbox-style-1', 'cspt-ihbox-style-hsbox', $ih_code );
				//$return .= '<div class="cspt-blog-ele-heading">' . $ih_code . '</div>';
			}

			/* Sortable Category  */
			if( function_exists('cspt_sortable_category') ){
				$return .= cspt_sortable_category( $atts, 'category' );
			}

			$return .= '</div>';

			// Preparing $args
			$args = array(
				'post_type'				=> 'post',
				'posts_per_page'		=> $show,
				//'paged'                 => esc_attr($paged),
				'ignore_sticky_posts'	=> true,
				//'orderby'				=> esc_attr($orderby),
				//'order'					=> esc_attr($order),
			);

			if( !empty($offset) ){
				$args['offset'] = $offset;
			}
			if( !empty($orderby) && $orderby!='none' ){
				$args['orderby'] = $orderby;
				if( !empty($order) ){
					$args['order'] = $order;
				}
			}

			// From selected category/group
			if( !empty($atts['from_category']) ){
				$term_array = explode(',', $atts['from_category']);
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'slug',
						'terms'    => $term_array,
					),
				);
			};

			// Wp query to fetch posts
			$posts = new WP_Query( $args );

			if ( $posts->have_posts() ) {

				$return .= '<div class="cspt-element-posts-wrapper row multi-columns-row">';

				$odd_even = 'odd';
				while ( $posts->have_posts() ) {

					$posts->the_post();

					// Template
					if( file_exists( locate_template( '/theme-parts/blog/blog-style-'.$style.'.php', false, false ) ) ){

						$return .= cspt_element_block_container( array(
							'position'	=> 'start',
							'column'	=> $columns,
							'cpt'		=> 'blog',
							'taxonomy'	=> 'category',
						) );

						ob_start();
						include( locate_template( '/theme-parts/blog/blog-style-'.$style.'.php', false, false ) );
						$return .= ob_get_contents();
						ob_end_clean();

						$return .= cspt_element_block_container( array(
							'position'	=> 'end',
						) );

					}

					// odd or even
					if( $odd_even == 'odd' ){ $odd_even = 'even'; } else { $odd_even = 'odd'; }

				}

				$return .= '</div>';

			}

		// Ending wrapper of the whole arear
		$return .= creativesplanet_element_container( array(
			'position'	=> 'end',
			'cpt'		=> 'blog',
			'data'		=> $atts
		) );

		/* Restore original Post Data */
		wp_reset_postdata();

	}

	return $return;

}
}
add_shortcode( 'cspt-blog', 'creativesplanet_sc_blog' );
