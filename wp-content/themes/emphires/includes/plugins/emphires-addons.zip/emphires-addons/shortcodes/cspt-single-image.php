<?php

if( !function_exists('creativesplanet_sc_single_image') ){
function creativesplanet_sc_single_image( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_single_image_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		// If image is selected
		if( !empty($image) && function_exists('wpb_getImageBySize') ){

			$img = wpb_getImageBySize( array(
				'attach_id'  => $image,
				'thumb_size' => $img_size,
				'class'      => 'cspt_vc_single_image-img',
			) );

			// image link
			$atag         = '';
			$overlay_html = '';
			if( !empty($link) ){

				// Overlay
				$icon_sc = '[vc_icon';
				foreach( get_defined_vars() as $key=>$val ){
					if( substr($key, 0, 2)=='i_' && !empty($val) ){
						$key = substr($key, 2, 99);
						$icon_sc .= ' '. $key .'="'. $val .'"';
					}
				}

				// Add lightbox link to icon too
				if( $link=='lightbox' || $link=='lightbox_video' ){
					if($link=='lightbox_video'){
						$icon_sc .= ' link="url:' . cspt_uencode($video_url) . '|||" el_class="cspt-lightbox cspt-lightbox-video"';
					} else {
						$image_src = wp_get_attachment_image_src($image, 'full');
						if( !empty($image_src[0]) ){
							$icon_sc .= ' link="url:' . cspt_uencode($image_src[0]) . '|||" el_class="cspt-lightbox cspt-lightbox-video"';
						}
					}

				}

				$icon_sc .= ']';
				$icon_html = do_shortcode($icon_sc);

				$overlay_html = '<div class="cspt-overlay">'.$icon_html.'</div>';

				switch( $link ){

					case 'normal':
						$url = vc_build_link( $img_link );
						if ( strlen( $url['url'] ) > 0 ) {
							$atag = '<a class="cspt-simage-link" href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '"><span class="creativesplanet-hide">'.esc_attr__('Click Here','emphires-addons').'</span></a>' ;
						}
						break;

					case 'lightbox':
						$image_src = wp_get_attachment_image_src($image, 'full');
						if( !empty($image_src[0]) ){
							$atag = '<a href="'.$image_src[0].'" class="cspt-lightbox"><span class="creativesplanet-hide">'.esc_attr__('Click Here','emphires-addons').'</span></a>' ;
						}
						break;

					case 'lightbox_video':
						if( !empty($video_url) ){
							$atag = '<a href="'.$video_url.'" class="cspt-lightbox cspt-lightbox-video"><span class="creativesplanet-hide">' . esc_attr__('Click Here','emphires-addons') . '</span></a>' ;
						}
						break;

				}  // switch

			}  // if

			// CSS Animation
			if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
				$el_class .= ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
			}

			// CSS Options custom class
			if( !empty($css) && function_exists('vc_shortcode_custom_css_class') ){
				$el_class .= ' '.vc_shortcode_custom_css_class( $css );
			}

			// Element ID
			$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;

			if( !empty($img['thumbnail']) ){  // check if image exists
				$return = '<div '.$elelemt_id.' class="cspt-single-image-w cspt-single-hover-'.$show_hover_icon.' '.$el_class.'">';
				$return .= $img['thumbnail'] . $overlay_html . $atag;
				$return .= '</div>';
			}

		}
	}

	return $return;

}
}
add_shortcode( 'cspt-single-image', 'creativesplanet_sc_single_image' );
