<?php

if( !function_exists('creativesplanet_sc_testimonial') ){
function creativesplanet_sc_testimonial( $atts, $content = "" ) {

	$ih_code = '';
	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_testimonial_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		$style	= ( !empty( $atts['style'] ) ) ? $atts['style'] : '1' ;  // Getting box style
		$column	= ( !empty( $atts['columns'] ) ) ? $atts['columns'] : '3' ; // Column
		$show	= ( !empty( $atts['show'] ) ) ? $atts['show'] : '3' ; // Show

		// Starting container
		$return .= creativesplanet_element_container( array(
			'position'	=> 'start',
			'cpt'		=> 'testimonial',
			'data'		=> $atts
		) );

		// Preparing heading and subheading
		if( !empty($atts['h_h2']) ){

			$ih_sc = '[cspt-icon-heading text="'.$atts['h_h2'].'" ';
			foreach( $atts as $key=>$val ){
				if( substr( $key, 0, 2 ) == 'h_' ){
					$ih_sc .= ' ' . substr( $key, 2 ) . '="'.$val.'" ';
				}
			}

			if( $atts['style']=='1' && !empty($atts['view-type']) && $atts['view-type']=='carousel' ){
				$ih_sc .= ' show_car_arrows="yes"';
			}
			$ih_sc .= ' icon_type="none"]';

			$ih_code = do_shortcode( $ih_sc );
			$ih_code = str_replace( 'cspt-ihbox-style-1', 'cspt-ihbox-style-hsbox', $ih_code );

			// Special design for Style-3
			if( $style!='2' ){
				$return .= $ih_code;
			}

		}

		// Preparing $args
		$args = array(
			'post_type'				=> 'cspt-testimonial',
			'posts_per_page'		=> $show,
			'ignore_sticky_posts'	=> true,
		);
		if( !empty($offset) ){
			$args['offset'] = $offset;
		}
		if( !empty($orderby) && $orderby!='none' ){
			$args['orderby'] = $orderby;
			if( !empty($order) ){
				$args['order'] = $order;
			}
		}

		// From selected category/group
		if( !empty($atts['from_category']) ){
			$term_array = explode(',', $atts['from_category']);
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'cspt-testimonial-group',
					'field'    => 'slug',
					'terms'    => $term_array,
				),
			);
		};

		// Wp query to fetch posts
		$posts = new WP_Query( $args );

		if ( $posts->have_posts() ) {

			$return .= '<div class="cspt-element-posts-wrapper row multi-columns-row">';

			$x		= 1;
			$boxes	= '';
			while ( $posts->have_posts() ) {
				$posts->the_post();

				$company_name_html = '';
				$company_name = get_post_meta( get_the_ID(), 'cspt-testimonial-company-name', true );
				$company_link = get_post_meta( get_the_ID(), 'cspt-testimonial-company-link', true );
				if( !empty($company_name) ){
					if( !empty($company_link) ){ $company_name = '<a href="' . esc_url($company_link) . '">'.$company_name.'</a>'; }
					$company_name_html = '<span class="cspt-designation">'.$company_name.'</span>';
				}

				// Template
				if( file_exists( locate_template( '/theme-parts/testimonial/testimonial-style-'.$style.'.php', false, false ) ) ){

					$boxes .= cspt_element_block_container( array(
						'position'	=> 'start',
						'column'	=> $column,
						'cpt'		=> 'testimonial',
					) );

					// active class
					$active_class = ( $x==1 ) ? ' cspt-testimonial-active' : '' ;

					$boxes .= '<article class="creativesplanet-ele creativesplanet-ele-testimonial cspt-testimonial-style-'.$style.$active_class.'">';
					ob_start();
					include( locate_template( '/theme-parts/testimonial/testimonial-style-'.$style.'.php', false, false ) );
					$boxes .= ob_get_contents();
					ob_end_clean();
					$boxes .= '</article>';

					$boxes .= cspt_element_block_container( array(
						'position'	=> 'end',
					) );

				}
				$x++;
			}

			$return .= $boxes;			
			$return .= '</div>';

		}

		// Ending wrapper of the whole arear
		$return .= creativesplanet_element_container( array(
			'position'	=> 'end',
			'cpt'		=> 'testimonial',
			'data'		=> $atts
		) );

		/* Restore original Post Data */
		wp_reset_postdata();

	}

	return $return;

}
}
add_shortcode( 'cspt-testimonial', 'creativesplanet_sc_testimonial' );
