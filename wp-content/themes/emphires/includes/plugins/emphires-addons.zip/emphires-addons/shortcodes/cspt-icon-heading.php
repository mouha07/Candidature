<?php

if( !function_exists('creativesplanet_sc_icon_heading') ){
function creativesplanet_sc_icon_heading( $atts, $content = "" ) {

	$return = $icon_html = $heading_html = $subheading_html = $content_html = $button_html = $mainclass = $nav_html = '';

	// Content
	$content_html = $content;

	$params = cspt_vc_iconheading_params();
	$default_atts = cspt_vc_prepare_default_options( $params );
	$default_atts['align'] = '';

	// Navigation for Carousel
	$with_nav = false;
	if( !empty($atts['heading-with-nav']) && $atts['heading-with-nav']=='true' ){
		$with_nav = true;
		$nav_html = '<div class="cspt-carousel-navs">
			<a href="#" class="cspt-carousel-prev"><i class="cspt-base-icon-angle-left"></i></a>
			<a href="#" class="cspt-carousel-next"><i class="cspt-base-icon-angle-right"></i></a>
		</div>';
	}

	// getting all attributes
	$atts = shortcode_atts( $default_atts, $atts );

	// Extract
	extract($atts);

	// Getting box style
	$boxstyle = ( !empty( $atts['boxstyle'] ) ) ? $atts['boxstyle'] : '1' ;

	// Heading
	if( !empty($atts['h2']) ){
		$h2_sc = '[vc_custom_heading text="'.$atts['h2'].'" ';
		foreach( $atts as $key=>$val ){
			if( substr( $key, 0, 3 ) == 'h2_' ){
				$h2_sc .= ' ' . substr( $key, 3 ) . '="'.$val.'" ';
			}
		}
		$h2_sc .= ']';
		$heading_html = '<div class="cspt-ihbox-heading">' . do_shortcode( $h2_sc ) . '</div>';
	}

	// Subheading
	if( !empty($atts['h4']) ){
		$atts['h4'] = nl2br($atts['h4']);
		$h4_sc = '[vc_custom_heading text="'.$atts['h4'].'" ';
		foreach( $atts as $key=>$val ){
			if( substr( $key, 0, 3 ) == 'h4_' ){
				$h4_sc .= ' ' . substr( $key, 3 ) . '="'.$val.'" ';
			}
		}
		$h4_sc .= ']';
		$subheading_html = '<div class="cspt-ihbox-subheading">' . do_shortcode( $h4_sc ) . '</div>';
		$subheading_html = str_replace( '<h2', '<h4', $subheading_html );
		$subheading_html = str_replace( '</h2>', '</h4>', $subheading_html );
	}

	// Reverse heading
	if( !empty($atts['reverse']) && $atts['reverse']=='yes' ){
		$heading_html_bkup	= $heading_html;
		$mainclass 		   .= ' cspt-reverse-heading-yes';
		$heading_html		= $subheading_html;
		$subheading_html	= $heading_html_bkup;

	}

	// Content
	if( !empty($content_html) ){
		$content_html = '<div class="cspt-ihbox-content">' . cspt_esc_kses( do_shortcode($content_html) ) . '</div>';
	}

	// main class
	if( !empty($atts['css_animation']) && !is_array($atts['css_animation']) && $atts['css_animation']!='Array' ){
		$mainclass .= ' wpb_animate_when_almost_visible wpb_'.$atts['css_animation'].' '.$atts['css_animation'].' ';
	}

	// align
	if( !empty($atts['align']) ){
		$mainclass .= ' cspt-align-'.$atts['align'];
	}

	// extra class
	if( !empty($atts['el_class']) ){
		$mainclass .= ' '.$atts['el_class'];
	}

	// Design options
	if( !empty($atts['css']) && function_exists('vc_shortcode_custom_css_class') ){
		$mainclass .= ' '. vc_shortcode_custom_css_class( $atts['css'] );
	}

	// Button
	if( !empty($atts['add_button']) && $atts['add_button']=='yes' ){
		$btn_sc = '[vc_btn ';
		foreach( $atts as $key=>$val ){
			if( substr( $key, 0, 4 ) == 'btn_' ){
				$btn_sc .= ' ' . substr( $key, 4 ) . '="'.$val.'" ';
			}
		}
		$btn_sc .= ']';

		$button_html = '<div class="cspt-ihbox-btn">' . do_shortcode($btn_sc) . '</div>';
	}

	if( shortcode_exists('vc_cta') ){

		/** ICON **/
		$icon_type_class = '';
		if( !empty($atts['icon_type']) ){

			if( $atts['icon_type']=='text' ){
				$icon_html = '<div class="cspt-ihbox-icon"><div class="cspt-ihbox-icon-wrapper cspt-ihbox-icon-type-text">' . $atts['small_text'] . '</div></div>';
				$icon_type_class = 'text';

			} else if( $atts['icon_type']=='image' ){
				$icon_image = wp_get_attachment_image($atts['icon_image'], 'full');
				$icon_html = '<div class="cspt-ihbox-icon"><div class="cspt-ihbox-icon-wrapper cspt-ihbox-icon-type-image">' . $icon_image . '</div></div>';
				$icon_type_class = 'image';
			} else if( $atts['icon_type']=='none' ){
				$icon_html = '';
				$icon_type_class = 'none';
			} else {
				// This is real icon html code
				$icon_class      = ( !empty( $atts[ 'i_icon_'.$atts['i_type'] ] ) ) ? $atts[ 'i_icon_'.$atts['i_type'] ] : '' ;
				$icon_html       = '<div class="cspt-ihbox-icon"><div class="cspt-ihbox-icon-wrapper"><i class="' . $icon_class . '"></i></div></div>';
				$icon_type_class = 'icon';
				wp_enqueue_style($atts['i_type']);
				if( function_exists('vc_icon_element_fonts_enqueue') ){
					vc_icon_element_fonts_enqueue($atts['i_type']);
				}
			}

		}

		// Template
		//if( file_exists( get_template_directory() . '/theme-parts/icon-heading/icon-heading-style-'.$boxstyle.'.php' ) ){
		if( file_exists( locate_template( '/theme-parts/icon-heading/icon-heading-style-'.$boxstyle.'.php', false, false ) ) ){
			ob_start();
			//include( get_template_directory() . '/theme-parts/icon-heading/icon-heading-style-'.$boxstyle.'.php' );
			include( locate_template( '/theme-parts/icon-heading/icon-heading-style-'.$boxstyle.'.php', false, false ) );
			$return = ob_get_contents();
			ob_end_clean();
		}

	}

	return $return;

}
}
add_shortcode( 'cspt-icon-heading', 'creativesplanet_sc_icon_heading' );
