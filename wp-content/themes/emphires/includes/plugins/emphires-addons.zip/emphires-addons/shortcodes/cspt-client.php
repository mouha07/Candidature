<?php

if( !function_exists('creativesplanet_sc_client') ){
function creativesplanet_sc_client( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_client_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		$style	= ( !empty( $atts['style'] ) ) ? $atts['style'] : '1' ;  // Getting box style
		$column	= ( !empty( $atts['columns'] ) ) ? $atts['columns'] : '3' ; // Column
		$show	= ( !empty( $atts['show'] ) ) ? $atts['show'] : '3' ; // Show

		// Starting container
		$return .= creativesplanet_element_container( array(
			'position'	=> 'start',
			'cpt'		=> 'cspt-client',
			'data'		=> $atts
		) );

		// Preparing heading and subheading
		if( !empty($atts['h_h2']) ){
			$ih_sc = '[cspt-icon-heading text="'.$atts['h_h2'].'" ';
			foreach( $atts as $key=>$val ){
				if( substr( $key, 0, 2 ) == 'h_' ){
					$ih_sc .= ' ' . substr( $key, 2 ) . '="'.$val.'" ';
				}
			}
			$ih_sc .= ' icon_type="none"]';

			$ih_code = do_shortcode( $ih_sc );
			$return .= str_replace( 'cspt-ihbox-style-1', 'cspt-ihbox-style-hsbox', $ih_code );
			//$return .= '<div class="cspt-client-ele-heading">' . $ih_code . '</div>';
		}

		// Preparing $args
		$args = array(
			'post_type'				=> 'cspt-client',
			'posts_per_page'		=> $show,
			//'paged'                 => esc_attr($paged),
			'ignore_sticky_posts'	=> true,
			//'orderby'				=> esc_attr($orderby),
			//'order'					=> esc_attr($order),
		);
		if( !empty($offset) ){
			$args['offset'] = $offset;
		}
		if( !empty($orderby) && $orderby!='none' ){
			$args['orderby'] = $orderby;
			if( !empty($order) ){
				$args['order'] = $order;
			}
		}

		// From selected category/group
		if( !empty($atts['from_category']) ){
			$term_array = explode(',', $atts['from_category']);
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'cspt-client-group',
					'field'    => 'slug',
					'terms'    => $term_array,
				),
			);
		};

		// Wp query to fetch posts
		$posts = new WP_Query( $args );

		if ( $posts->have_posts() ) {

			$return .= '<div class="cspt-element-posts-wrapper row multi-columns-row">';

			while ( $posts->have_posts() ) {
				$posts->the_post();

				// Template
				//if( file_exists( get_template_directory() . '/theme-parts/client/client-style-'.$style.'.php' ) ){
				if( file_exists( locate_template( '/theme-parts/client/client-style-'.$style.'.php', false, false ) ) ){

					$return .= cspt_element_block_container( array(
						'position'	=> 'start',
						'column'	=> $column,
						'cpt'		=> 'client',
					) );

					$return .= '<article class="creativesplanet-ele creativesplanet-ele-client cspt-client-style-'.$style.'">';
					ob_start();
					//include( get_template_directory() . '/theme-parts/client/client-style-'.$style.'.php' );
					include( locate_template( '/theme-parts/client/client-style-'.$style.'.php', false, false ) );
					$return .= ob_get_contents();
					ob_end_clean();
					$return .= '</article>';

					$return .= cspt_element_block_container( array(
						'position'	=> 'end',
					) );

				}

			}

			$return .= '</div>';

		}

		// Ending wrapper of the whole arear
		$return .= creativesplanet_element_container( array(
			'position'	=> 'end',
			'cpt'		=> 'client',
			'data'		=> $atts
		) );

		/* Restore original Post Data */
		wp_reset_postdata();

	}

	return $return;

}
}
add_shortcode( 'cspt-client', 'creativesplanet_sc_client' );
