<?php

if( !function_exists('creativesplanet_sc_list') ){
function creativesplanet_sc_list( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_list_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		$css_class = 'creativesplanet-ul-list';

		// Extra Class
		if( !empty($el_class) ){
			$css_class .= ' ' . $el_class;
		}

		// List type
		if( !empty($type) ){
			$css_class .= ' cspt-ul-type-' . $type;
		}

		// Default library
		$i_type = ( !empty($i_type) ) ? $i_type : 'fontawesome' ;

		// Enqueue style
		wp_enqueue_style($i_type);

		$i_class = ( !empty($atts['i_icon_'.$i_type]) ) ? $atts['i_icon_'.$i_type] : 'fa fa-user-o' ;

		// icon
		$icon_html = '';
		if( $type=='icon' ){
			$icon_html = '<i class="cspt-globalcolor '.esc_attr($i_class).'"></i> ';
		}

		// CSS Options class
		if( function_exists('cspt_vc_shortcode_custom_css_class') ){
			$custom_css_class = vc_shortcode_custom_css_class($css);
			if( !empty($custom_css_class) ){
				$css_class .= ' ' . $custom_css_class;
			}
		}

		// CSS Animation
		if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
			$css_class .= ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
		}

		// CSS Options custom class
		if( !empty($css) && function_exists('vc_shortcode_custom_css_class') ){
			$css_class .= ' '.vc_shortcode_custom_css_class( $css );
		}

		// Element ID
		$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;

		// Return
		for( $i =1; $i<=10; $i++ ) {
			// col1_heading
			if( !empty( $atts['line_'.$i] ) ){
				$line = rawurldecode(base64_decode(trim( $atts['line_'.$i] )));
				$line = $icon_html . $line;
				$return .= '<li>'.cspt_esc_kses($line).'</li>';
			}
		}

		if( !empty($return) ){
			$return = '<div '.$elelemt_id.' class="' . esc_attr( $css_class ) . '"><ul>'.$return.'</ul></div>';
		}

	}

	return $return;

}
}
add_shortcode( 'cspt-list', 'creativesplanet_sc_list' );
