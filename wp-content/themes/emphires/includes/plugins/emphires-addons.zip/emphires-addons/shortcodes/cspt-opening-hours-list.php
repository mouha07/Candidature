<?php

if( !function_exists('creativesplanet_sc_opening_hours_list') ){
function creativesplanet_sc_opening_hours_list( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$style = '1';
		$params = cspt_vc_opening_hours_list_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		$css_class = 'creativesplanet-ohlists-w wpb_content_element';

		// Extra Class
		if( !empty($el_class) ){
			$css_class .= ' ' . $el_class;
		}

		// CSS Options class
		if( function_exists('cspt_vc_shortcode_custom_css_class') ){
			$custom_css_class = vc_shortcode_custom_css_class($css);
			if( !empty($custom_css_class) ){
				$css_class .= ' ' . $custom_css_class;
			}
		}

		// CSS Animation
		if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
			$css_class .= ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
		}

		// CSS Options custom class
		if( !empty($css) && function_exists('vc_shortcode_custom_css_class') ){
			$css_class .= ' '.vc_shortcode_custom_css_class( $css );
		}

		// Element ID
		$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;

		/* *********************************************************************** */
		/* ************************** Generating Output ************************** */

		$return .= '<div '.$elelemt_id.' class="' . esc_attr( $css_class ) . '">';

		$list = '';
		if( !empty($atts['firstline-left']) || !empty($atts['firstline-right']) ){
			$list .= '<li><span class="cspt-list-left">'.$atts['firstline-left'].'</span><span class="cspt-list-right">'.$atts['firstline-right'].'</span></li>';
		}
		if( !empty($atts['secondline-left']) || !empty($atts['secondline-right']) ){
			$list .= '<li><span class="cspt-list-left">'.$atts['secondline-left'].'</span><span class="cspt-list-right">'.$atts['secondline-right'].'</span></li>';
		}
		if( !empty($atts['thirdline-left']) || !empty($atts['thirdline-right']) ){
			$list .= '<li><span class="cspt-list-left">'.$atts['thirdline-left'].'</span><span class="cspt-list-right">'.$atts['thirdline-right'].'</span></li>';
		}
		if( !empty($list) ){
			$return .= '<ul class="cspt-ohlist-ul">'.$list.'</ul>';
		}

		$return .= '</div>';

		if( !empty($return) ){
			$return = '<div class="creativesplanet-ele creativesplanet-ele-opening-hours-list cspt-opening-hours-list-style-'.esc_attr($style).'">'.$return.'</div>';
		}

	}

	return $return;

}
}
add_shortcode( 'cspt-opening-hours-list', 'creativesplanet_sc_opening_hours_list' );
