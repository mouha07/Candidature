<?php
if( !function_exists('creativesplanet_sc_timeline') ){
function creativesplanet_sc_timeline( $atts, $content = "" ) {
	$return = '';
	if( function_exists('vc_map') ){
		$params = cspt_vc_timeline_params();
		$default_atts = cspt_vc_prepare_default_options( $params );
		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );
		// Extract array
		extract($atts);
		$css_class = 'cspt-timeline';
		// Extra Class
		if( !empty($el_class) ){
			$css_class .= ' ' . $el_class;
		}
		// Timeline type
		if( !empty($type) ){
			$css_class .= ' cspt-ul-type-' . $type;
		}
		// Main content
		$return = '';
		if( !empty($values) ){
			$values = json_decode( urldecode( $values ), true );
			if( !empty($values) && is_array($values) && count($values)>0 ){
				foreach( $values as $value ){
					// image
					$image = '';
					if( !empty($value['image']) ){ $image = wp_get_attachment_image($value['image'], 'full'); }
					// small text
					$small_text = ( !empty($value['small_text']) ) ? $value['small_text'] : '' ;
					// Title
					$title_text = ( !empty($value['title_text']) ) ? $value['title_text'] : '' ;
					// Desc Text
					$desc_text = ( !empty($value['desc_text']) ) ? $value['desc_text'] : '' ;
					$return .= '
						<div class=" col-sm-12 cspt-ourhistory cspt-ourhistory-type2 ">
							<div class="row cspt-ourhistory-row">
								<div class="col-md-3  col-sm-3 col-xs-3">
									'.$image.'
								</div>
								<div class="col-md-1 cspt-ourhistory-left">
									<span class="label">'.$small_text.'</span>
								</div>
								<div class="col-md-8 col-sm-8 col-xs-8 cspt-ourhistory-right">
									<span class="cspt-timeline-image">'.$image.'</span>
									<span class="label">'.$small_text.'</span>
									<div class="content">
										<h4>'.$title_text.'</h4>
										<div class="simple-text">
											<p>'.$desc_text.'</p>
										</div>
									</div>
								</div>
							</div> 
						</div>
					';
				}
			}
		}
		// CSS Options class
		if( function_exists('cspt_vc_shortcode_custom_css_class') ){
			$custom_css_class = vc_shortcode_custom_css_class($css);
			if( !empty($custom_css_class) ){
				$css_class .= ' ' . $custom_css_class;
			}
		}
		// CSS Animation
		if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
			wp_enqueue_style('animate-css');
			$css_class .= ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
		}
		// CSS Options custom class
		if( !empty($css) && function_exists('vc_shortcode_custom_css_class') ){
			$css_class .= ' '.vc_shortcode_custom_css_class( $css );
		}
		// Element ID
		$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;
		if( !empty($return) ){
			$return = '<div '.$elelemt_id.' class="' . esc_attr( $css_class ) . '"><div class="cspt-timeline-inner">'.$return.'</div></div>';
		}
	}
	return $return;
}
}
add_shortcode( 'cspt-timeline', 'creativesplanet_sc_timeline' );