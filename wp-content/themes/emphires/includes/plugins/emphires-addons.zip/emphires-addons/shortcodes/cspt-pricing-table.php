<?php

if( !function_exists('creativesplanet_sc_pricing_table') ){
function creativesplanet_sc_pricing_table( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_pricing_table_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		$css_class = 'creativesplanet-ptables-w wpb_content_element';

		// Extra Class
		if( !empty($el_class) ){
			$css_class .= ' ' . $el_class;
		}

		// CSS Options class
		if( function_exists('cspt_vc_shortcode_custom_css_class') ){
			$custom_css_class = vc_shortcode_custom_css_class($css);
			if( !empty($custom_css_class) ){
				$css_class .= ' ' . $custom_css_class;
			}
		}

		// CSS Animation
		if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
			$css_class .= ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
		}

		// CSS Options custom class
		if( !empty($css) && function_exists('vc_shortcode_custom_css_class') ){
			$css_class .= ' '.vc_shortcode_custom_css_class( $css );
		}

		// Element ID
		$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;

		/* *********************************************************************** */
		/* ************************** Generating Output ************************** */

		$return .= '<div '.$elelemt_id.' class="' . esc_attr( $css_class ) . '">';

		$columns = array();
		$x = 0;
		for( $i = 0; $i<=5; $i++ ) {

			// col1_heading
			if( !empty( $atts['col'.$i.'_heading'] ) ){
				$columns[$x] = $i;
			}
			$x++;
		}

		$col_start_div	= '';
		$col_end_div	= '';
		if( !empty($columns) ){
			switch( count($columns) ){
				case 1:
					$col_start_div	= '<div class="col-md-12">';
					$col_end_div	= '</div>';
					break;

				case 2:
					$col_start_div	= '<div class="col-md-6">';
					$col_end_div	= '</div>';
					break;

				case 3:
					$col_start_div	= '<div class="col-md-4">';
					$col_end_div	= '</div>';
					break;

				case 4:
					$col_start_div	= '<div class="col-md-3">';
					$col_end_div	= '</div>';
					break;

				case 5:
					$col_start_div	= '<div class="col-md-20percent">';
					$col_end_div	= '</div>';
					break;
			}
		}

		if( !empty($columns) ){

			$return .= '<div class="row multi-columns-row">';

			foreach( $columns as $key=>$val ){

				// Defalt icon library
				$atts['col'.$val.'_i_type'] = ( empty($atts['col'.$val.'_i_type']) ) ? 'fontawesome' : $atts['col'.$val.'_i_type'] ;

				// Enqueue file
				wp_enqueue_style($atts['col'.$val.'_i_type']);

				// Icon
				$icon = '';
				if( !empty($atts['col'.$val.'_i_type']) && !empty($atts['col'.$val.'_i_icon_' . $atts['col'.$val.'_i_type'] ]) ){
					$icon = '<div class="cspt-ptablebox-main-icon"><i class="' . $atts['col'.$val.'_i_icon_' . $atts['col'.$val.'_i_type'] ] . '"></i></div>';
				}

				// Featured
				$featured = ( !empty($atts['featured_col']) && $atts['featured_col']==$val ) ? '<div class="cspt-ptablebox-featured-w">'.$atts['featured_text'].'</div>' : '' ;

				// Heading
				$heading = ( !empty($atts['col'.$val.'_heading']) ) ? '<h3 class="creativesplanet-ptable-heading">'.$atts['col'.$val.'_heading'].'</h3><div class="creativesplanet-sep"></div>' : '' ;

				// Currency Symbol
				$currency_symbol = ( !empty($atts['col'.$val.'_cur_symbol']) ) ? '<div class="creativesplanet-ptable-symbol">'.$atts['col'.$val.'_cur_symbol'].'</div>' : '' ;

				// Price Frequency
				$frequency = ( !empty($atts['col'.$val.'_price_frequency']) ) ? '<div class="creativesplanet-ptable-frequency">'.$atts['col'.$val.'_price_frequency'].'</div>' : '' ;

				// Price				
				$price = ( !empty($atts['col'.$val.'_price']) ) ? '<div class="creativesplanet-ptable-price">'.$atts['col'.$val.'_price'].'</div>' : '' ;
				// Add currently symbol in price
				$price = ( !empty($atts['col'.$val.'_cur_symbol_position']) && $atts['col'.$val.'_cur_symbol_position']=='before' ) ? $currency_symbol.' '.$price : $price.' '.$currency_symbol ;

				// Button
				$button = '';
				if( !empty($atts['col'.$val.'_btn_title']) && !empty($atts['col'.$val.'_btn_link']) ){
					$btn_sc = '[vc_btn title="'.$atts['col'.$val.'_btn_title'].'" style="classic" shape="round" link="'.$atts['col'.$val.'_btn_link'].'"]';
					$button = do_shortcode( $btn_sc );
				}

				// list of features
				$lines_html = '';
				$values     = (array) vc_param_group_parse_atts( $atts['col'.$val.'_values'] );
				if( is_array($values) && count($values)>0 ){
					foreach ( $values as $data ) {
						$list_icon = '<i class="fa fa-check"></i> ';
						if( !empty($data['icon_class']) ){
							$list_icon = '<i class="' . $data['icon_class'] . '"></i> ';
						}
						$lines_html .= isset( $data['label'] ) ? '<div class="cspt-ptable-line">'.$list_icon.$data['label'].'</div>' : '';
					}
				}

				// add featured class
				if( !empty($featured) ){
					$col_start_div = str_replace( 'class="', 'class="cspt-pricing-table-featured-col ', $col_start_div );
				} else {
					$col_start_div = str_replace( 'class="cspt-pricing-table-featured-col ', 'class="', $col_start_div );
				}

				// Template output
				$return .= $col_start_div;
				ob_start();
				include( get_template_directory() . '/theme-parts/pricing-table/pricing-table-style-'.$style.'.php' );
				$return .= ob_get_contents();
				ob_end_clean();
				$return .= $col_end_div;
			}

			$return .= '</div>';

		}

		$return .= '</div>';

		if( !empty($return) ){
			$return = '<div class="creativesplanet-ele creativesplanet-ele-pricing-table cspt-pricing-table-style-'.esc_attr($style).'">'.$return.'</div>';
		}

	}

	return $return;

}
}
add_shortcode( 'cspt-pricing-table', 'creativesplanet_sc_pricing_table' );
