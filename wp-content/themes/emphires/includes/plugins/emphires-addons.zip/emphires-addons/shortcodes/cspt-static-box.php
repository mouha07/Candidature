<?php

if( !function_exists('creativesplanet_sc_static_box') ){
function creativesplanet_sc_static_box( $atts, $content = "" ) {

	$return = '';

	$params = cspt_vc_static_content_params();
	$default_atts = cspt_vc_prepare_default_options( $params );

	// getting all attributes
	$atts = shortcode_atts( $default_atts, $atts );

	extract($atts);

	// Starting container
	$return .= creativesplanet_element_container( array(
		'position'	=> 'start',
		'cpt'		=> 'static_box',
		'data'		=> $atts
	) );

		// Preparing heading and subheading
		if( !empty($atts['h_h2']) ){
			$ih_sc = '[cspt-icon-heading text="'.$atts['h_h2'].'" ';
			foreach( $atts as $key=>$val ){
				if( substr( $key, 0, 2 ) == 'h_' ){
					$ih_sc .= ' ' . substr( $key, 2 ) . '="'.$val.'" ';
				}
			}
			$ih_sc .= ' icon_type="none"]';

			$ih_code = do_shortcode( $ih_sc );
			$return .= str_replace( 'cspt-ihbox-style-1', 'cspt-ihbox-style-hsbox', $ih_code );
			//$return .= '<div class="cspt-static_box-ele-heading">' . $ih_code . '</div>';
		}

		if( !empty($values) && function_exists('vc_param_group_parse_atts') ){

				$boxes = (array) vc_param_group_parse_atts( $values );

				$return .= '<div class="cspt-element-posts-wrapper row multi-columns-row">';

				foreach( $boxes as $box ){

					$smalltext_html  = ( !empty($box['smalltext']) ) ? '<div class="creativesplanet-static-box-desc">'.$box['smalltext'].'</div>' : '' ;
					$image_html = '' ;

					if( !empty($box['boximage']) ){

						if( function_exists('wpb_getImageBySize') ){
							$image_html = wpb_getImageBySize( array(
								'attach_id'  => $box['boximage'],
								'thumb_size' => $img_size,
								'class'      => 'cspt_vc_single_image-img',
							) );
							$image_html = ( !empty($image_html['thumbnail']) ) ? $image_html['thumbnail'] : '' ;
						} else {
							$image_html = wp_get_attachment_image( $box['boximage'], 'full' );
						}

					}

					$label_html      = ( !empty($box['label']) ) ? '<div class="creativesplanet-box-title"><h4>'.$box['label'].'</h4></div>' : '' ;

					// Template
					if( file_exists( locate_template( '/theme-parts/static-box/static-box-style-'.$style.'.php', false, false ) ) ){

						$return .= cspt_element_block_container( array(
							'position'	=> 'start',
							'column'	=> $columns,
							'cpt'		=> 'staticbox',
						) );

						ob_start();
						include( locate_template( '/theme-parts/static-box/static-box-style-'.$style.'.php', false, false ) );
						$return .= ob_get_contents();
						ob_end_clean();

						$return .= cspt_element_block_container( array(
							'position'	=> 'end',
						) );

					}

				} // foreach
				$return .= '</div><!-- .row multi-columns-row creativesplanet-boxes-row-wrapper -->  ';

			} // if

	// Ending wrapper of the whole arear
	$return .= creativesplanet_element_container( array(
		'position'	=> 'end',
		'cpt'		=> 'static_box',
		'data'		=> $atts
	) );

	return $return;

}
}
add_shortcode( 'cspt-static-box', 'creativesplanet_sc_static_box' );
