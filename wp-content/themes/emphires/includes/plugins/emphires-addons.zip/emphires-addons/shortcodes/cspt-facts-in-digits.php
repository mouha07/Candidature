<?php

if( !function_exists('creativesplanet_sc_facts_in_digits') ){
function creativesplanet_sc_facts_in_digits( $atts, $content = "" ) {

	$return = '';

	if( function_exists('vc_map') ){

		$params = cspt_vc_facts_in_digits_params();
		$default_atts = cspt_vc_prepare_default_options( $params );

		// getting all attributes
		$atts = shortcode_atts( $default_atts, $atts );

		// Extract array
		extract($atts);

		// Enqueue scripts
		wp_enqueue_script( 'waypoints' );
		wp_enqueue_script( 'numinate' );
		if( $style=='5' ){ wp_enqueue_script( 'jquery-circle-progress' ); }

		// Global Color
		$global_color = cspt_get_base_option('global-color');

		// Secondary Color
		$secondary_color = cspt_get_base_option('secondary-color');

		// Light Background Color
		$light_bg_color = cspt_get_base_option('light-bg-color');

		// Blackish Color
		$blackish_color = cspt_get_base_option('blackish-color');

		// Secondary Color
		$gradient_color = cspt_get_base_option('gradient-color');
		$gradient1 = ( !empty($gradient_color['first']) ) ? $gradient_color['first'] : '#ff00ff' ;
		$gradient2 = ( !empty($gradient_color['last'])  ) ? $gradient_color['last']  : '#ff0000' ;

		//  Icon
		$icon_class   = ( !empty( ${'i_icon_'.$i_type} ) ) ? ${'i_icon_'.$i_type} : '' ;
		if( !empty($i_type) ){ wp_enqueue_style($i_type); } 
		$icon = '<div class="cspt-sbox-icon-wrapper"><i class="' . $icon_class . '"></i></div>';

		//  Before or after text
		$before_text = '';
		$after_text  = '';
		if( !empty($before) ){
			if( in_array($beforetextstyle, array( 'sup', 'sub', 'span' ) ) ){
				$before_text = '<'.$beforetextstyle.'>'.$before.'</'.$beforetextstyle.'>';
			}
		}
		if( !empty($after) ){
			if( in_array($aftertextstyle, array( 'sup', 'sub', 'span' ) ) ){
				$after_text = '<'.$aftertextstyle.'>'.$after.'</'.$aftertextstyle.'>';
			}
		}

		// Title
		//$title = ( !empty($title) ) ? '<h3 class="cspt-fid-title">' . $before_text . $title . $after_text . '</h3>' : '' ;

		$class   = array();
		// CSS Animation
		if( !empty($css_animation) && !is_array($css_animation) && $css_animation!='Array' ){
			$class[] = ' wpb_animate_when_almost_visible wpb_'.$css_animation.' '.$css_animation.' ';
		}
		// Extra Class
		if( !empty($el_class) ){
			$class[] = $el_class;
		}
		// VC custom class
		if ( ! empty( $css ) ) {
			$class[] = vc_shortcode_custom_css_class( $css );
		}

		// Element ID
		$elelemt_id = ( ! empty( $el_id ) ) ? 'id="'.$el_id.'"' : '' ;

		if( file_exists( locate_template( '/theme-parts/facts-in-digits/facts-in-digits-style-'.$style.'.php', false, false ) ) ){

			$return .= '<div '.$elelemt_id.' class="creativesplanet-ele creativesplanet-ele-fid creativesplanet-ele-fid-style-'.$style.' ' . implode( ' ', $class ) . '">';
			ob_start();
			//include( get_template_directory() . '/theme-parts/facts-in-digits/facts-in-digits-style-'.$style.'.php' );
			include( locate_template( '/theme-parts/facts-in-digits/facts-in-digits-style-'.$style.'.php', false, false ) );
			$return .= ob_get_contents();
			ob_end_clean();
			$return .= '</div>';

		}

	}

	return $return;

}
}
add_shortcode( 'cspt-facts-in-digits', 'creativesplanet_sc_facts_in_digits' );
