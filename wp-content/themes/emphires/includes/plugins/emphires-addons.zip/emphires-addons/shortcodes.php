<?php

// Shortcode files

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-icon-heading.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-icon-heading.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-heading-subheading.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-heading-subheading.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-blog.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-blog.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-portfolio.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-portfolio.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-service.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-service.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-team.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-team.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-testimonial.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-testimonial.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-client.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-client.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-single-image.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-single-image.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-static-box.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-static-box.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-facts-in-digits.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-facts-in-digits.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-list.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-list.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-timeline.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-timeline.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-pricing-table.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-pricing-table.php' );
}

if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-opening-hours-list.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-opening-hours-list.php' );
}

/* Shortcode without element */
if( file_exists( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-social-links.php' ) ){
	include( EMPHIRES_ADDON_PATH . '/shortcodes/cspt-social-links.php' );
}
