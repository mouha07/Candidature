<?php

if( !function_exists('cspt_vc_map_add_css_animation') ){
function cspt_vc_map_add_css_animation( $args = array() ) {

	$styles = array(
		array(
			'values' => array(
				__( 'None', 'js_composer' ) => 'none',
			),
		),
		array(
			'label' => __( 'Attention Seekers', 'js_composer' ),
			'values' => array(
				// text to display => value
				esc_attr__( 'bounce', 'js_composer' ) => array(
					'value' => 'bounce',
					'type' => 'other',
				),
				esc_attr__( 'flash', 'js_composer' ) => array(
					'value' => 'flash',
					'type' => 'other',
				),
				esc_attr__( 'pulse', 'js_composer' ) => array(
					'value' => 'pulse',
					'type' => 'other',
				),
				esc_attr__( 'rubberBand', 'js_composer' ) => array(
					'value' => 'rubberBand',
					'type' => 'other',
				),
				esc_attr__( 'shake', 'js_composer' ) => array(
					'value' => 'shake',
					'type' => 'other',
				),
				esc_attr__( 'swing', 'js_composer' ) => array(
					'value' => 'swing',
					'type' => 'other',
				),
				esc_attr__( 'tada', 'js_composer' ) => array(
					'value' => 'tada',
					'type' => 'other',
				),
				esc_attr__( 'wobble', 'js_composer' ) => array(
					'value' => 'wobble',
					'type' => 'other',
				),
			),
		),
		array(
			'label' => __( 'Bouncing Entrances', 'js_composer' ),
			'values' => array(
				// text to display => value
				esc_attr__( 'bounceIn', 'js_composer' ) => array(
					'value' => 'bounceIn',
					'type' => 'in',
				),
				esc_attr__( 'bounceInDown', 'js_composer' ) => array(
					'value' => 'bounceInDown',
					'type' => 'in',
				),
				esc_attr__( 'bounceInLeft', 'js_composer' ) => array(
					'value' => 'bounceInLeft',
					'type' => 'in',
				),
				esc_attr__( 'bounceInRight', 'js_composer' ) => array(
					'value' => 'bounceInRight',
					'type' => 'in',
				),
				esc_attr__( 'bounceInUp', 'js_composer' ) => array(
					'value' => 'bounceInUp',
					'type' => 'in',
				),
			),
		),
		array(
			'label' => __( 'Bouncing Exits', 'js_composer' ),
			'values' => array(
				// text to display => value
				esc_attr__( 'bounceOut', 'js_composer' ) => array(
					'value' => 'bounceOut',
					'type' => 'out',
				),
				esc_attr__( 'bounceOutDown', 'js_composer' ) => array(
					'value' => 'bounceOutDown',
					'type' => 'out',
				),
				esc_attr__( 'bounceOutLeft', 'js_composer' ) => array(
					'value' => 'bounceOutLeft',
					'type' => 'out',
				),
				esc_attr__( 'bounceOutRight', 'js_composer' ) => array(
					'value' => 'bounceOutRight',
					'type' => 'out',
				),
				esc_attr__( 'bounceOutUp', 'js_composer' ) => array(
					'value' => 'bounceOutUp',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Fading Entrances', 'js_composer' ),
			'values' => array(
				// text to display => value
				esc_attr__( 'fadeIn', 'js_composer' ) => array(
					'value' => 'fadeIn',
					'type' => 'in',
				),
				esc_attr__( 'fadeInDown', 'js_composer' ) => array(
					'value' => 'fadeInDown',
					'type' => 'in',
				),
				esc_attr__( 'fadeInDownBig', 'js_composer' ) => array(
					'value' => 'fadeInDownBig',
					'type' => 'in',
				),
				esc_attr__( 'fadeInLeft', 'js_composer' ) => array(
					'value' => 'fadeInLeft',
					'type' => 'in',
				),
				esc_attr__( 'fadeInLeftBig', 'js_composer' ) => array(
					'value' => 'fadeInLeftBig',
					'type' => 'in',
				),
				esc_attr__( 'fadeInRight', 'js_composer' ) => array(
					'value' => 'fadeInRight',
					'type' => 'in',
				),
				esc_attr__( 'fadeInRightBig', 'js_composer' ) => array(
					'value' => 'fadeInRightBig',
					'type' => 'in',
				),
				esc_attr__( 'fadeInUp', 'js_composer' ) => array(
					'value' => 'fadeInUp',
					'type' => 'in',
				),
				esc_attr__( 'fadeInUpBig', 'js_composer' ) => array(
					'value' => 'fadeInUpBig',
					'type' => 'in',
				),
			),
		),
		array(
			'label' => __( 'Fading Exits', 'js_composer' ),
			'values' => array(
				esc_attr__( 'fadeOut', 'js_composer' ) => array(
					'value' => 'fadeOut',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutDown', 'js_composer' ) => array(
					'value' => 'fadeOutDown',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutDownBig', 'js_composer' ) => array(
					'value' => 'fadeOutDownBig',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutLeft', 'js_composer' ) => array(
					'value' => 'fadeOutLeft',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutLeftBig', 'js_composer' ) => array(
					'value' => 'fadeOutLeftBig',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutRight', 'js_composer' ) => array(
					'value' => 'fadeOutRight',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutRightBig', 'js_composer' ) => array(
					'value' => 'fadeOutRightBig',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutUp', 'js_composer' ) => array(
					'value' => 'fadeOutUp',
					'type' => 'out',
				),
				esc_attr__( 'fadeOutUpBig', 'js_composer' ) => array(
					'value' => 'fadeOutUpBig',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Flippers', 'js_composer' ),
			'values' => array(
				esc_attr__( 'flip', 'js_composer' ) => array(
					'value' => 'flip',
					'type' => 'other',
				),
				esc_attr__( 'flipInX', 'js_composer' ) => array(
					'value' => 'flipInX',
					'type' => 'in',
				),
				esc_attr__( 'flipInY', 'js_composer' ) => array(
					'value' => 'flipInY',
					'type' => 'in',
				),
				esc_attr__( 'flipOutX', 'js_composer' ) => array(
					'value' => 'flipOutX',
					'type' => 'out',
				),
				esc_attr__( 'flipOutY', 'js_composer' ) => array(
					'value' => 'flipOutY',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Lightspeed', 'js_composer' ),
			'values' => array(
				esc_attr__( 'lightSpeedIn', 'js_composer' ) => array(
					'value' => 'lightSpeedIn',
					'type' => 'in',
				),
				esc_attr__( 'lightSpeedOut', 'js_composer' ) => array(
					'value' => 'lightSpeedOut',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Rotating Entrances', 'js_composer' ),
			'values' => array(
				esc_attr__( 'rotateIn', 'js_composer' ) => array(
					'value' => 'rotateIn',
					'type' => 'in',
				),
				esc_attr__( 'rotateInDownLeft', 'js_composer' ) => array(
					'value' => 'rotateInDownLeft',
					'type' => 'in',
				),
				esc_attr__( 'rotateInDownRight', 'js_composer' ) => array(
					'value' => 'rotateInDownRight',
					'type' => 'in',
				),
				esc_attr__( 'rotateInUpLeft', 'js_composer' ) => array(
					'value' => 'rotateInUpLeft',
					'type' => 'in',
				),
				esc_attr__( 'rotateInUpRight', 'js_composer' ) => array(
					'value' => 'rotateInUpRight',
					'type' => 'in',
				),
			),
		),
		array(
			'label' => __( 'Rotating Exits', 'js_composer' ),
			'values' => array(
				esc_attr__( 'rotateOut', 'js_composer' ) => array(
					'value' => 'rotateOut',
					'type' => 'out',
				),
				esc_attr__( 'rotateOutDownLeft', 'js_composer' ) => array(
					'value' => 'rotateOutDownLeft',
					'type' => 'out',
				),
				esc_attr__( 'rotateOutDownRight', 'js_composer' ) => array(
					'value' => 'rotateOutDownRight',
					'type' => 'out',
				),
				esc_attr__( 'rotateOutUpLeft', 'js_composer' ) => array(
					'value' => 'rotateOutUpLeft',
					'type' => 'out',
				),
				esc_attr__( 'rotateOutUpRight', 'js_composer' ) => array(
					'value' => 'rotateOutUpRight',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Specials', 'js_composer' ),
			'values' => array(
				esc_attr__( 'hinge', 'js_composer' ) => array(
					'value' => 'hinge',
					'type' => 'out',
				),
				esc_attr__( 'rollIn', 'js_composer' ) => array(
					'value' => 'rollIn',
					'type' => 'in',
				),
				esc_attr__( 'rollOut', 'js_composer' ) => array(
					'value' => 'rollOut',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Zoom Entrances', 'js_composer' ),
			'values' => array(
				esc_attr__( 'zoomIn', 'js_composer' ) => array(
					'value' => 'zoomIn',
					'type' => 'in',
				),
				esc_attr__( 'zoomInDown', 'js_composer' ) => array(
					'value' => 'zoomInDown',
					'type' => 'in',
				),
				esc_attr__( 'zoomInLeft', 'js_composer' ) => array(
					'value' => 'zoomInLeft',
					'type' => 'in',
				),
				esc_attr__( 'zoomInRight', 'js_composer' ) => array(
					'value' => 'zoomInRight',
					'type' => 'in',
				),
				esc_attr__( 'zoomInUp', 'js_composer' ) => array(
					'value' => 'zoomInUp',
					'type' => 'in',
				),
			),
		),
		array(
			'label' => __( 'Zoom Exits', 'js_composer' ),
			'values' => array(
				esc_attr__( 'zoomOut', 'js_composer' ) => array(
					'value' => 'zoomOut',
					'type' => 'out',
				),
				esc_attr__( 'zoomOutDown', 'js_composer' ) => array(
					'value' => 'zoomOutDown',
					'type' => 'out',
				),
				esc_attr__( 'zoomOutLeft', 'js_composer' ) => array(
					'value' => 'zoomOutLeft',
					'type' => 'out',
				),
				esc_attr__( 'zoomOutRight', 'js_composer' ) => array(
					'value' => 'zoomOutRight',
					'type' => 'out',
				),
				esc_attr__( 'zoomOutUp', 'js_composer' ) => array(
					'value' => 'zoomOutUp',
					'type' => 'out',
				),
			),
		),
		array(
			'label' => __( 'Slide Entrances', 'js_composer' ),
			'values' => array(
				esc_attr__( 'slideInDown', 'js_composer' ) => array(
					'value' => 'slideInDown',
					'type' => 'in',
				),
				esc_attr__( 'slideInLeft', 'js_composer' ) => array(
					'value' => 'slideInLeft',
					'type' => 'in',
				),
				esc_attr__( 'slideInRight', 'js_composer' ) => array(
					'value' => 'slideInRight',
					'type' => 'in',
				),
				esc_attr__( 'slideInUp', 'js_composer' ) => array(
					'value' => 'slideInUp',
					'type' => 'in',
				),
			),
		),
		array(
			'label' => __( 'Slide Exits', 'js_composer' ),
			'values' => array(
				esc_attr__( 'slideOutDown', 'js_composer' ) => array(
					'value' => 'slideOutDown',
					'type' => 'out',
				),
				esc_attr__( 'slideOutLeft', 'js_composer' ) => array(
					'value' => 'slideOutLeft',
					'type' => 'out',
				),
				esc_attr__( 'slideOutRight', 'js_composer' ) => array(
					'value' => 'slideOutRight',
					'type' => 'out',
				),
				esc_attr__( 'slideOutUp', 'js_composer' ) => array(
					'value' => 'slideOutUp',
					'type' => 'out',
				),
			),
		),
	);

	$data = array(
		'type' => 'animation_style',
		'heading' => __( 'CSS Animation', 'js_composer' ),
		'param_name' => 'css_animation',
		//'admin_label' => $label,
		'value' => $styles,
		'std' => '',
		/*
		'settings' => array(
			'type' => 'in',
			'custom' => array(
				array(
					'label' => __( 'Default', 'js_composer' ),
					'values' => array(
						esc_attr__( 'Top to bottom', 'js_composer' ) => 'top-to-bottom',
						esc_attr__( 'Bottom to top', 'js_composer' ) => 'bottom-to-top',
						esc_attr__( 'Left to right', 'js_composer' ) => 'left-to-right',
						esc_attr__( 'Right to left', 'js_composer' ) => 'right-to-left',
						esc_attr__( 'Appear from center', 'js_composer' ) => 'appear',
					),
				),
			),
		),
		*/
		'description' => __( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'js_composer' ),
	);

	if( !empty($args['group']) ){
		$data['group'] = $args['group'];
	}

	return $data;
}
}

function cspt_vc_heading_params( $prefix='', $group='' ){

	$h2_custom_heading = vc_map_integrate_shortcode( 'vc_custom_heading', 'h2_', esc_attr__( 'Heading', 'emphires-addons' ), array(
		'exclude' => array(
			'txt_align',
			'source',
			'text',
			'css',
		),
	), array(
		'element' => 'use_custom_foncspt_h2',
		'value' => 'true',
	) );

	// This is needed to remove custom heading _tag and _align options.
	if ( is_array( $h2_custom_heading ) && ! empty( $h2_custom_heading ) ) {
		foreach ( $h2_custom_heading as $key => $param ) {
			if ( is_array( $param ) && isset( $param['type'] ) && 'font_container' === $param['type'] ) {
				$h2_custom_heading[ $key ]['value'] = '';
				if ( isset( $param['settings'] ) && is_array( $param['settings'] ) && isset( $param['settings']['fields'] ) ) {
					$sub_key = array_search( 'tag', $param['settings']['fields'] );
					if ( false !== $sub_key ) {
						unset( $h2_custom_heading[ $key ]['settings']['fields'][ $sub_key ] );
					} elseif ( isset( $param['settings']['fields']['tag'] ) ) {
						unset( $h2_custom_heading[ $key ]['settings']['fields']['tag'] );
					}
					$sub_key = array_search( 'text_align', $param['settings']['fields'] );
					if ( false !== $sub_key ) {
						unset( $h2_custom_heading[ $key ]['settings']['fields'][ $sub_key ] );
					} elseif ( isset( $param['settings']['fields']['text_align'] ) ) {
						unset( $h2_custom_heading[ $key ]['settings']['fields']['text_align'] );
					}
				}
			}
			if( !empty($param) && $param['param_name']=='h2_use_theme_fonts' ){
				$h2_custom_heading[$key]['std'] = 'yes';
			}
		}
	}
	$h4_custom_heading = vc_map_integrate_shortcode( 'vc_custom_heading', 'h4_', esc_attr__( 'Subheading', 'emphires-addons' ), array(
		'exclude' => array(
			'source',
			'text',
			'css',
		),
	), array(
		'element' => 'use_custom_foncspt_h4',
		'value' => 'true',
	) );

	// This is needed to remove custom heading _tag and _align options.
	if ( is_array( $h4_custom_heading ) && ! empty( $h4_custom_heading ) ) {
		foreach ( $h4_custom_heading as $key => $param ) {
			if ( is_array( $param ) && isset( $param['type'] ) && 'font_container' === $param['type'] ) {
				$h4_custom_heading[ $key ]['value'] = '';
				if ( isset( $param['settings'] ) && is_array( $param['settings'] ) && isset( $param['settings']['fields'] ) ) {
					$sub_key = array_search( 'tag', $param['settings']['fields'] );
					if ( false !== $sub_key ) {
						unset( $h4_custom_heading[ $key ]['settings']['fields'][ $sub_key ] );
					} elseif ( isset( $param['settings']['fields']['tag'] ) ) {
						unset( $h4_custom_heading[ $key ]['settings']['fields']['tag'] );
					}
					$sub_key = array_search( 'text_align', $param['settings']['fields'] );
					if ( false !== $sub_key ) {
						unset( $h4_custom_heading[ $key ]['settings']['fields'][ $sub_key ] );
					} elseif ( isset( $param['settings']['fields']['text_align'] ) ) {
						unset( $h4_custom_heading[ $key ]['settings']['fields']['text_align'] );
					}
				}
			}
			if( !empty($param) && $param['param_name']=='h4_use_theme_fonts' ){
				$h4_custom_heading[$key]['std'] = 'yes';
			}
		}
	}

	$params = array_merge(

		array(
			array(
				'type'				=> 'textarea',
				'heading'			=> esc_attr__( 'Heading', 'emphires-addons' ),
				'admin_label'		=> true,
				'param_name'		=> 'h2',
				'value'				=> esc_attr__( 'Welcome to our site', 'emphires-addons' ),
				'description'		=> esc_attr__( 'Enter text for heading line.', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-9',
				'group'				=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'				=> 'checkbox',
				'heading'			=> esc_attr__( 'Use custom font?', 'emphires-addons' ),
				'param_name'		=> 'use_custom_foncspt_h2',
				'description'		=> esc_attr__( 'Enable Google fonts.', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-3',
				'group'				=> esc_attr__( 'Content', 'emphires-addons' ),
			),

		),

		array(
			array(
				'type'				=> 'textarea',
				'heading'			=> esc_attr__( 'Subheading', 'emphires-addons' ),
				'param_name'		=> 'h4',
				'value'				=> '',
				'description'		=> esc_attr__( 'Enter text for subheading line.', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-9',
				'group'				=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'				=> 'checkbox',
				'heading'			=> esc_attr__( 'Use custom font?', 'emphires-addons' ),
				'param_name'		=> 'use_custom_foncspt_h4',
				'description'		=> esc_attr__( 'Enable custom font option.', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-3',
				'group'				=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'				=> 'textarea_html',
				//'type'				=> 'textarea',
				'heading'			=> esc_attr__( 'Text', 'emphires-addons' ),
				'param_name'		=> 'content',
				//'param_name'		=> 'description',
				'value'				=> '',
				'description'		=> esc_attr__( 'Enter text for short paragraph here.', 'emphires-addons' ),
				'group'				=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		$h2_custom_heading,

		$h4_custom_heading,

		array(
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_attr__( 'Heading area Alignment', 'emphires-addons' ) . '?',
				'description'	=> esc_attr__( 'All heading text alignment.', 'emphires-addons' ),
				'param_name'	=> 'align',
				'value'			=> array(
					esc_attr__( 'Left (default)', 'emphires-addons' )	=> '',
					esc_attr__( 'Right', 'emphires-addons' )			=> 'right',
					esc_attr__( 'Center', 'emphires-addons' )			=> 'center',
				),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_attr__( 'Show Subheading before heading?', 'emphires-addons' ) . '?',
				'description'	=> esc_attr__( 'Show sub-heading before heading. This is also called reverse heading', 'emphires-addons' ),
				'param_name'	=> 'reverse',
				'value'			=> array(
					esc_attr__( 'No', 'emphires-addons' )	=> '',
					esc_attr__( 'Yes', 'emphires-addons' )			=> 'yes',
				),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		)

	);

	// Applying prefix
	if( !empty($prefix) ){
		foreach( $params as $key=>$param ){
			$params[$key]['param_name'] = $prefix . $param['param_name'];
			if( !empty($param['dependency']['element']) ){
				$params[$key]['dependency']['element'] = $prefix . $param['dependency']['element'];
			}

		}
	}

	// Change group
	if( !empty($group) ){
		foreach( $params as $key=>$val ){
			$params[$key]['group'] = esc_attr__( $group, 'emphires-addons' );
		}
	}

	return $params;
}

if( !function_exists('cspt_vc_box_element_content_params') ){
function cspt_vc_box_element_content_params( $cpt='blog', $args = array() ) {

	/*
	// Default titles

	*/

	// Get CPT title
	$cpt_title			= esc_attr__('Posts','emphires-addons');
	$cpt_singular_title	= esc_attr__('Post','emphires-addons');
	$cat_title			= esc_attr__('Blog Categories','emphires-addons');
	$cat_singular_title	= esc_attr__('Blog Category','emphires-addons');

	// Get category list
	$categories    = get_categories( array('hide_empty' => false) );
	$category_array = array();
	foreach($categories as $category){
		$category_array[ esc_attr($category->name) . ' (' . esc_attr($category->count) . ')' ] = esc_attr( $category->slug );
	}

	if( $cpt=='portfolio' ){
		$cpt_title			= esc_attr__('Portfolio','emphires-addons');
		$cpt_singular_title	= esc_attr__('Portfolio','emphires-addons');
		$cat_title			= esc_attr__('Portfolio Categories','emphires-addons');
		$cat_singular_title	= esc_attr__('Portfolio Category','emphires-addons');

		if( class_exists('Kirki') ){

			// Dynamic Name
			$cpt_title2	= Kirki::get_option( 'portfolio-cpt-title' );
			$cpt_title	= ( !empty($cpt_title2) ) ? $cpt_title2 : $cpt_title ;

			$cpt_singular_title2	= Kirki::get_option( 'portfolio-cpt-singular-title' );
			$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;

			$cat_title2	= Kirki::get_option( 'portfolio-cat-title' );
			$cat_title	= ( !empty($cat_title2) ) ? $cat_title2 : $cat_title ;

			$cat_singular_title2	= Kirki::get_option( 'portfolio-cat-singular-title' );
			$cat_singular_title		= ( !empty($cat_singular_title2) ) ? $cat_singular_title2 : $cat_singular_title ;
		}

		// Get category list

		$terms			= get_terms( array( 'taxonomy' => 'cspt-portfolio-category', 'hide_empty' => false ) );
		$category_array = array();
		foreach($terms as $term){
			$category_array[ esc_attr($term->name) . ' (' . esc_attr($term->count) . ')' ] = esc_attr( $term->slug );
		}

	} else if( $cpt=='service' ){
		$cpt_title			= esc_attr__('Service','emphires-addons');
		$cpt_singular_title	= esc_attr__('Service','emphires-addons');
		$cat_title			= esc_attr__('Service Categories','emphires-addons');
		$cat_singular_title	= esc_attr__('Service Category','emphires-addons');

		if( class_exists('Kirki') ){

			// Dynamic Name
			$cpt_title2	= Kirki::get_option( 'service-cpt-title' );
			$cpt_title	= ( !empty($cpt_title2) ) ? $cpt_title2 : $cpt_title ;

			$cpt_singular_title2	= Kirki::get_option( 'service-cpt-singular-title' );
			$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;

			$cat_title2	= Kirki::get_option( 'service-cat-title' );
			$cat_title	= ( !empty($cat_title2) ) ? $cat_title2 : $cat_title ;

			$cat_singular_title2	= Kirki::get_option( 'service-cat-singular-title' );
			$cat_singular_title		= ( !empty($cat_singular_title2) ) ? $cat_singular_title2 : $cat_singular_title ;
		}

		// Get category list

		$terms			= get_terms( array( 'taxonomy' => 'cspt-service-category', 'hide_empty' => false ) );
		$category_array = array();
		foreach($terms as $term){
			$category_array[ esc_attr($term->name) . ' (' . esc_attr($term->count) . ')' ] = esc_attr( $term->slug );
		}

	} else if( $cpt=='team' ){
		$cpt_title				= esc_attr__('Team Members','emphires-addons');
		$cpt_singular_title		= esc_attr__('Team Member','emphires-addons');
		$cat_title				= esc_attr__('Team Groups','emphires-addons');
		$cat_singular_title		= esc_attr__('Team Group','emphires-addons');

		if( class_exists('Kirki') ){

			// Dynamic Name
			$cpt_title2	= Kirki::get_option( 'team-cpt-title' );
			$cpt_title	= ( !empty($cpt_title2) ) ? $cpt_title2 : $cpt_title ;

			$cpt_singular_title2	= Kirki::get_option( 'team-cpt-singular-title' );
			$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;

			$cat_title2	= Kirki::get_option( 'team-group-title' );
			$cat_title	= ( !empty($cat_title2) ) ? $cat_title2 : $cat_title ;

			$cat_singular_title2	= Kirki::get_option( 'team-group-singular-title' );
			$cat_singular_title		= ( !empty($cat_singular_title2) ) ? $cat_singular_title2 : $cat_singular_title ;
		}

		// Get category list
		$terms = get_terms( 'cspt-team-group', array( 'hide_empty' => false ) );
		$category_array = array();
		foreach($terms as $term){
			$category_array[ esc_attr($term->name) . ' (' . esc_attr($term->count) . ')' ] = esc_attr( $term->slug );
		}

	} else if( $cpt=='testimonial' ){
		$cpt_title				= esc_attr__('Testimonials','emphires-addons');
		$cpt_singular_title		= esc_attr__('Testimonial','emphires-addons');
		$cat_title				= esc_attr__('Testimonial Groups','emphires-addons');
		$cat_singular_title		= esc_attr__('Testimonial Group','emphires-addons');

		if( class_exists('Kirki') ){

			// Dynamic Name
			$cpt_title2	= Kirki::get_option( 'testimonial-cpt-title' );
			$cpt_title	= ( !empty($cpt_title2) ) ? $cpt_title2 : $cpt_title ;

			$cpt_singular_title2	= Kirki::get_option( 'testimonial-cpt-singular-title' );
			$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;

			$cat_title2	= Kirki::get_option( 'testimonial-group-title' );
			$cat_title	= ( !empty($cat_title2) ) ? $cat_title2 : $cat_title ;

			$cat_singular_title2	= Kirki::get_option( 'testimonial-group-singular-title' );
			$cat_singular_title		= ( !empty($cat_singular_title2) ) ? $cat_singular_title2 : $cat_singular_title ;
		}

		// Get category list
		$terms = get_terms( 'cspt-testimonial-group', array( 'hide_empty' => false ) );
		$category_array = array();
		foreach($terms as $term){
			$category_array[ esc_attr($term->name) . ' (' . esc_attr($term->count) . ')' ] = esc_attr( $term->slug );
		}

	} else if( $cpt=='client' ){
		$cpt_title				= esc_attr__('Clients','emphires-addons');
		$cpt_singular_title		= esc_attr__('Client','emphires-addons');
		$cat_title				= esc_attr__('Client Groups','emphires-addons');
		$cat_singular_title		= esc_attr__('Client Group','emphires-addons');

		// Get category list
		$terms = get_terms( 'cspt-client-group', array( 'hide_empty' => false ) );
		$category_array = array();
		foreach($terms as $term){
			$category_array[ esc_attr($term->name) . ' (' . esc_attr($term->count) . ')' ] = esc_attr( $term->slug );
		}

	}

	$return = array_merge(

		array(

			// Content Options
			array(
				'type'			=> 'dropdown',
				'heading'		=> sprintf( esc_attr__('Skip %1$s (offset)', 'emphires-addons'), $cpt_singular_title ),
				'description'	=> sprintf( esc_attr__('How many %1$s you like to skip.', 'emphires-addons') , $cpt_singular_title ),
				'param_name'	=> 'offset',
				'value'			=> array(
					sprintf( esc_attr__('Show All %1$s (No skip)','emphires-addons'), $cpt_singular_title )	=> '',
					sprintf( esc_attr__('Skip first %1$s','emphires-addons'), $cpt_singular_title )			=> '1',
					sprintf( esc_attr__('Skip two %1$s','emphires-addons'), $cpt_title )						=> '2',
					sprintf( esc_attr__('Skip three %1$s','emphires-addons'), $cpt_title )					=> '3',
					sprintf( esc_attr__('Skip four %1$s','emphires-addons'), $cpt_title )						=> '4',
					sprintf( esc_attr__('Skip five %1$s','emphires-addons'), $cpt_title )						=> '5',
				),
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
				'std'			=> '',
			),
			array(
				'type'        => 'checkbox',
				'heading'     => sprintf( esc_attr__('Show %1$s from %2$s?', 'emphires-addons'), $cpt_singular_title, $cat_singular_title ),
				'description' => sprintf( esc_attr__('Show %2$s from selected %1$s only. If you like to show %2$s from all %1$s than don\'t select any checkbox.', 'emphires-addons') , $cat_singular_title, $cpt_singular_title ),
				'param_name'  => 'from_category',
				'value'       => $category_array,
				'group'		  => esc_attr__( 'Content Options', 'emphires-addons' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => sprintf( esc_attr__('%1$s to show','emphires-addons'), $cpt_singular_title ),
				"description" => sprintf( esc_attr__('How many %1$s you want to show.','emphires-addons'), $cpt_singular_title ),
				"param_name"  => "show",
				"value"       => array(
					esc_attr__('Show All','emphires-addons') => '-1',
					esc_attr__('1','emphires-addons')		=> '1',
					esc_attr__('2','emphires-addons')		=> '2',
					esc_attr__('3','emphires-addons')		=> '3',
					esc_attr__('4','emphires-addons')		=> '4',
					esc_attr__('5','emphires-addons')		=> '5',
					esc_attr__('6','emphires-addons')		=> '6',
					esc_attr__('7','emphires-addons')		=> '7',
					esc_attr__('8','emphires-addons')		=> '8',
					esc_attr__('9','emphires-addons')		=> '9',
					esc_attr__('10','emphires-addons')		=> '10',
					esc_attr__('11','emphires-addons')		=> '11',
					esc_attr__('12','emphires-addons')		=> '12',
					esc_attr__('13','emphires-addons')		=> '13',
					esc_attr__('14','emphires-addons')		=> '14',
					esc_attr__('15','emphires-addons')		=> '15',
					esc_attr__('16','emphires-addons')		=> '16',
					esc_attr__('17','emphires-addons')		=> '17',
					esc_attr__('18','emphires-addons')		=> '18',
					esc_attr__('19','emphires-addons')		=> '19',
					esc_attr__('20','emphires-addons')		=> '20',
					esc_attr__('21','emphires-addons')		=> '21',
					esc_attr__('22','emphires-addons')		=> '22',
					esc_attr__('23','emphires-addons')		=> '23',
					esc_attr__('24','emphires-addons')		=> '24',
					esc_attr__('25','emphires-addons')		=> '25',
					esc_attr__('26','emphires-addons')		=> '26',
					esc_attr__('27','emphires-addons')		=> '27',
					esc_attr__('28','emphires-addons')		=> '28',
					esc_attr__('29','emphires-addons')		=> '29',
					esc_attr__('30','emphires-addons')		=> '30',
				),
				"std"  => "3",
				'group'		  => esc_attr__( 'Content Options', 'emphires-addons' ),
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> sprintf( esc_attr__('Show Sortable %1$s ?', 'emphires-addons'), $cat_singular_title ),
				'description'	=> sprintf( esc_attr__('Select YES to show sortable %1$s.', 'emphires-addons') , $cat_singular_title ),
				'param_name'	=> 'sortable',
				'value'			=> array(
					esc_attr__('No','emphires-addons')	=> 'no',
					esc_attr__('Yes','emphires-addons')	=> 'yes',
				),
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
				'std'			=> 'no',
			),

			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => sprintf( esc_attr__('Order','emphires-addons'), $cpt_singular_title ),
				"description" => esc_attr__('Designates the ascending or descending order.','emphires-addons'),
				"param_name"  => "order",
				"value"       => array(
					esc_attr__('Ascending order (1, 2, 3; a, b, c)','emphires-addons')	=> 'ASC',
					esc_attr__('Descending order (3, 2, 1; c, b, a)','emphires-addons')	=> 'DESC',
				),
				"std"  => "ASC",
				'group'		  => esc_attr__( 'Content Options', 'emphires-addons' ),
			),
			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => sprintf( esc_attr__('Order By','emphires-addons'), $cpt_singular_title ),
				"description" => esc_attr__('Sort retrieved posts by.','emphires-addons'),
				"param_name"  => "orderby",
				"value"       => array(
					esc_attr__('No order','emphires-addons')	=> 'none',
					esc_attr__('ID','emphires-addons')		=> 'ID',
					esc_attr__('Title','emphires-addons')		=> 'title',
					esc_attr__('Date','emphires-addons')		=> 'date',
					esc_attr__('Random','emphires-addons')	=> 'rand',
				),
				"std"  => "none",
				'group'		  => esc_attr__( 'Content Options', 'emphires-addons' ),
			),

			array(
				"type"        => "dropdown",
				"holder"      => "div",
				"class"       => "",
				"heading"     => esc_attr__('Box Gap','emphires-addons'),
				"description" => sprintf( esc_attr__('Gap between each %1$s box.','emphires-addons'), $cpt_singular_title ),
				"param_name"  => "gap",
				"value"       => array(
					esc_attr__('Default','emphires-addons')		=> '',
					esc_attr__('No Gap (0px)','emphires-addons')	=> '0px',
					esc_attr__('5px','emphires-addons')			=> '5px',
					esc_attr__('10px','emphires-addons')			=> '10px',
					esc_attr__('15px','emphires-addons')			=> '15px',
					esc_attr__('20px','emphires-addons')			=> '20px',
					esc_attr__('25px','emphires-addons')			=> '25px',
					esc_attr__('30px','emphires-addons')			=> '30px',
					esc_attr__('40px','emphires-addons')			=> '40px',
					esc_attr__('50px','emphires-addons')			=> '50px',
				),
				"std"  => "3",
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
				'dependency'	=> array(
					'element'		=> 'view-type',
					'value'			=> array('row-column'),
				)
			),

			cspt_vc_map_add_css_animation( array('group' => esc_attr__('Content Options','emphires-addons') ) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
			)
		),

		cspt_vc_box_element_appearance_params( $cpt_singular_title ),

		// CSS Style Option
		array(
			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)

	);

	// Special option for special Testimonial style
	/*
	if( $cpt=='testimonial' ){
		$return = array_merge(
			array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__( 'Left Image', 'emphires-addons' ),
					'description'	=> esc_html__( 'Slect image that appear at left side', 'emphires-addons' ),
					'param_name'	=> 'left_image',
					'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
					'dependency' 	=> array(
						'element'		=> 'style',
						'value'			=> array('2'),
					)
				),
			),
			array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__( 'Background Image', 'emphires-addons' ),
					'description'	=> esc_html__( 'Slect image that appear as background', 'emphires-addons' ),
					'param_name'	=> 'bg_image',
					'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
					'dependency' 	=> array(
						'element'		=> 'style',
						'value'			=> array('1'),
					)
				),
			),
			$return
		);
	}
	*/

	return $return;
}
}

if( !function_exists('cspt_vc_box_element_appearance_params') ){
function cspt_vc_box_element_appearance_params( $cpt_singular_title='' ) {

	$return = array(
	// Appearance
		array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=>  sprintf( esc_attr__( 'How you like to view each %1$s box?', 'emphires-addons' ), $cpt_singular_title ),
			'description'	=> esc_attr__( 'Show as carousel view or simple row-column view', 'emphires-addons' ),
			'param_name'	=> 'view-type',
			'std'			=> 'row-column',
			'value'			=> array(
				array(
					'label'		=> esc_attr('Row Column view','emphires-addons'),
					'value'		=> 'row-column',
					'thumb'		=> EMPHIRES_ADDON_URL . 'images/row-column.png',
				),
				array(
					'label'		=> esc_attr('Carousel view','emphires-addons'),
					'value'		=> 'carousel',
					'thumb'		=> EMPHIRES_ADDON_URL . 'images/carousel.png',
				),
			),
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Carousel: Loop', 'emphires-addons' ),
			'param_name'	=> 'carousel-loop',
			'description'	=> esc_attr__( 'Infinity loop. Duplicate last and first items to get loop illusion.', 'emphires-addons' ),
			'value'			=> array(
				esc_attr__('Yes','emphires-addons')	=> '1',
				esc_attr__('No','emphires-addons')		=> '0',
			),
			'std'			=> '0',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Carousel: Autoplay', 'emphires-addons' ),
			'param_name'	=> 'carousel-autoplay',
			'description'	=> esc_attr__( 'Autoplay of carousel.', 'emphires-addons' ),
			'value'			=> array(
				esc_attr__('Yes','emphires-addons')	=> '1',
				esc_attr__('No','emphires-addons')	=> '0',
			),
			'std'			=> '0',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Carousel: Center', 'emphires-addons' ),
			'param_name'	=> 'carousel-center',
			'description'	=> esc_attr__( 'Center item. Works well with even an odd number of items.', 'emphires-addons' ),
			'value'			=> array(
				esc_attr__('Yes','emphires-addons')	=> '1',
				esc_attr__('No','emphires-addons')	=> '0',
			),
			'std'			=> '0',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Carousel: Nav', 'emphires-addons' ),
			'param_name'	=> 'carousel-nav',
			'description'	=> esc_attr__( 'Show next/prev buttons.', 'emphires-addons' ),
			'value'			=> array(
				esc_attr__('Yes','emphires-addons')				=> '1',
				esc_attr__('Yes, with title','emphires-addons')	=> 'above',
				esc_attr__('No','emphires-addons')				=> '0',
			),
			'std'			=> '0',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Carousel: Dots', 'emphires-addons' ),
			'param_name'	=> 'carousel-dots',
			'description'	=> esc_attr__( 'Show dots navigation.', 'emphires-addons' ),
			'value'			=> array(
				esc_attr__('Yes','emphires-addons')	=> '1',
				esc_attr__('No','emphires-addons')	=> '0',
			),
			'std'			=> '0',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),
		array(
			'type'				=> 'textfield',
			'heading'			=> esc_attr__( 'Carousel: autoplaySpeed', 'emphires-addons' ),
			'admin_label'		=> true,
			'param_name'		=> 'carousel-autoplayspeed',
			'value'				=> esc_attr('1000'),
			'description'	=> esc_attr__( 'autoplay speed.', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-4',
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
			'dependency' 	=> array(
				'element'		=> 'view-type',
				'value'			=> array('carousel'),
			)
		),

		array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__( 'View in Column', 'emphires-addons' ),
			'description'	=> esc_attr__( 'Select how many column to show', 'emphires-addons' ),
			'param_name'	=> 'columns',
			'std'			=> '3',
			'value'			=> array(
				array(
					'label'	=> esc_attr('One Column','emphires-addons'),
					'value'	=> '1',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-1.png',
					'width'	=> '33%',
				),
				array(
					'label'	=> esc_attr('Two Columns','emphires-addons'),
					'value'	=> '2',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-2.png',
					'width'	=> '33%',
				),
				array(
					'label'	=> esc_attr('Three Columns','emphires-addons'),
					'value'	=> '3',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-3.png',
					'width'	=> '33%',
				),
				array(
					'label'	=> esc_attr('Four Columns','emphires-addons'),
					'value'	=> '4',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-4.png',
					'width'	=> '33%',
				),
				array(
					'label'	=> esc_attr('Five Columns','emphires-addons'),
					'value'	=> '5',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-5.png',
					'width'	=> '33%',
				),
				array(
					'label'	=> esc_attr('Six Columns','emphires-addons'),
					'value'	=> '6',
					'thumb'	=> EMPHIRES_ADDON_URL . 'images/column-6.png',
					'width'	=> '33%',
				),
			),
			'group'			=> esc_attr__( 'Appearance', 'emphires-addons' ),
		)
	);

	return $return;

}
}

/*
 *  Element list
 */
include( EMPHIRES_ADDON_PATH . 'vc/elements/icon-heading.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/heading-subheading.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/blog.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/portfolio.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/service.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/team.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/testimonial.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/clients.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/single-image.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/static-box.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/facts-in-digits.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/list.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/timeline.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/pricing-table.php' );
include( EMPHIRES_ADDON_PATH . 'vc/elements/opening-hours-list.php' );

