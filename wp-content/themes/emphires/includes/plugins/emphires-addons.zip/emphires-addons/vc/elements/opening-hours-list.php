<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_opening_hours_list_params(){

	$params = array_merge(

		array(

			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '1st line - left content', 'emphires-addons' ),
				'std'			=> esc_attr__( 'Monday - Friday', 'emphires-addons' ),
				'param_name'	=> 'firstline-left',
				'description'	=> esc_attr__( 'Enter text that will be shown at left side of the 1st line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '1st line - right content', 'emphires-addons' ),
				'std'			=> esc_attr__( '8:00am - 7:00pm', 'emphires-addons' ),
				'param_name'	=> 'firstline-right',
				'description'	=> esc_attr__( 'Enter text that will be shown at right side of the 1st line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '2nd line - left content', 'emphires-addons' ),
				'std'			=> esc_attr__( 'Saturday', 'emphires-addons' ),
				'param_name'	=> 'secondline-left',
				'description'	=> esc_attr__( 'Enter text that will be shown at left side of the 2nd line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '2nd line - right content', 'emphires-addons' ),
				'std'			=> esc_attr__( '7:30am - 4:00pm', 'emphires-addons' ),
				'param_name'	=> 'secondline-right',
				'description'	=> esc_attr__( 'Enter text that will be shown at right side of the 2nd line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '3rd line - left content', 'emphires-addons' ),
				'std'			=> esc_attr__( 'Sunday', 'emphires-addons' ),
				'param_name'	=> 'thirdline-left',
				'description'	=> esc_attr__( 'Enter text that will be shown at left side of the 3rd line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '3rd line - right content', 'emphires-addons' ),
				'std'			=> esc_attr__( 'Closed', 'emphires-addons' ),
				'param_name'	=> 'thirdline-right',
				'description'	=> esc_attr__( 'Enter text that will be shown at right side of the 3rd line', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),

		),

		array(

			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'General Settings', 'emphires-addons' ),) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
		),

		array(

			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)

	);

	return $params;

}

function cspt_vc_opening_hours_list(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Opening Hours List Element', 'emphires-addons' ),
		'base'		=> 'cspt-opening-hours-list',
		'icon'		=> 'cspt-vc-icon cspt-icon-opening-hours-list',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_opening_hours_list_params(),
	);
}
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-opening-hours-list', 'cspt_vc_opening_hours_list');
}
