<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
if( !function_exists('cspt_vc_heading_subheading_params') ){
function cspt_vc_heading_subheading_params( $settings=array() ){

	// Get all heading and subheading elements
	$params = cspt_vc_heading_params();

	// Change default value
	foreach ( $params as $key => $val ) {
		if( isset($val['param_name']) && $val['param_name']=='h2_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='h4_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='i_type' ){
			$params[ $key ]['std'] = 'fontawesome';
		} else if( isset($val['param_name']) && $val['param_name']=='h2' ){
			$params[ $key ]['std'] = esc_attr__('This is heading', 'emphires-addons');
		} else if( isset($val['param_name']) && $val['param_name']=='description' ){
			$params[ $key ]['std'] = '';
		}
	}

	$params = array_merge(
		$params,

		array(
			cspt_vc_map_add_css_animation( array('group' => esc_attr__('Content','emphires-addons') ) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		array(
			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)
	);

	return $params;

}
}

function cspt_vc_heading_subheading(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Heading and Subheading Element', 'emphires-addons' ),
		'base'		=> 'cspt-heading-subheading',
		'icon'		=> 'cspt-vc-icon cspt-icon-heading-subheading',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_heading_subheading_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_heading_subheading', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-heading-subheading', 'cspt_vc_heading_subheading');
}

