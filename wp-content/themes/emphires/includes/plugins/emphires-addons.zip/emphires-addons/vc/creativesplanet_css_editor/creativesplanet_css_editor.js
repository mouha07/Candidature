// Tab click event
jQuery('.cspt-css-editor-tab-w a').on('click', function(){
	var parentmain = jQuery(this).closest('.creativesplanet-css-editor-w');
	var size = jQuery(this).data('cspt-size');

	// change tab active
	jQuery('.cspt-css-editor-tab-w li', parentmain ).removeClass('cspt-css-editor-tab-active');
	jQuery('.cspt-css-editor-tab-w a[data-cspt-size="'+size+'"]', parentmain ).parent().addClass('cspt-css-editor-tab-active');

	// change content active
	jQuery('.creativesplanet-css-editor', parentmain).slideUp();
	jQuery('.creativesplanet-css-editor-'+size, parentmain).slideDown();
});

jQuery( ".creativesplanet-css-editor-w input[type='text']:not(.cspt-main-value-input), .creativesplanet-css-editor-w input[type='checkbox']" ).on( 'change', function() {
	var parentmain = jQuery(this).closest('.creativesplanet-css-editor-w');
	var mainval    = '';

	jQuery( "input[type='text']:not(.cspt-main-value-input), input[type='checkbox']", parentmain ).each(function() {
		if( jQuery(this).attr('type')=='checkbox' ){
			if( jQuery(this).is(':checked') ){
				mainval += 'colbreak_yes|';
			} else {
				mainval += 'colbreak_no|';
			}
		} else {
			mainval += jQuery(this).val() + '|';
		}
	});

	jQuery('input.cspt-main-value-input', parentmain ).val( mainval );

});