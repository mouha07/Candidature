<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_timeline_params(){

	// Heading options	
	$heading_options = cspt_vc_heading_params( 'h_' , 'Title Settings' );

	// Style options
	/*
	$style_option = array(
        array(
            'type'			=> 'creativesplanet_imgselector',
            'heading'		=> esc_attr__( 'Timeline View Style', 'emphires-addons' ),
            'description'	=> esc_attr__( 'Select Timeline view style.', 'emphires-addons' ),
            'param_name'	=> 'style',
            'std'			=> '1',
            'value'			=> cspt_element_template_list('timeline', true),
            'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
		)
	);
	*/

	// Content options
	$params = array(

		array(
			'type'			=> 'param_group',
			'heading'		=> esc_attr__( 'Values', 'emphires-addons' ),
			'param_name'	=> 'values',
			'description'	=> esc_attr__( 'Enter values for graph - value, title and color.', 'emphires-addons' ),
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			'value'			=> '',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_attr__( 'Select Image', 'emphires-addons' ),
					'param_name'	=> 'image',
					'description'	=> esc_attr__( 'Enter text used as title of bar.', 'emphires-addons' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_attr__( 'Small Text', 'emphires-addons' ),
					'param_name'	=> 'small_text',
					'description'	=> esc_attr__( 'Small text like year.', 'emphires-addons' ),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_attr__( 'Title', 'emphires-addons' ),
					'param_name'	=> 'title_text',
					'description'	=> esc_attr__( 'Title Text.', 'emphires-addons' ),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_attr__( 'Description', 'emphires-addons' ),
					'param_name'	=> 'desc_text',
					'description'	=> esc_attr__( 'Description Text.', 'emphires-addons' ),
				),
			),
		),

	);

	// merging extra options like css animation, css options etc
	$params = array_merge(

		//$style_option,

		$heading_options,

		$params,

		array(

			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'Content', 'emphires-addons' ),) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		array( array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
		) )
	);

	return $params;

}

function cspt_vc_timeline(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Timeline Element', 'emphires-addons' ),
		'base'		=> 'cspt-timeline',
		'icon'		=> 'cspt-vc-icon cspt-icon-timeline',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_timeline_params(),
	);
}
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-timeline', 'cspt_vc_timeline');
}

