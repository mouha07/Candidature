<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_portfolio_params(){

	$heading_options = cspt_vc_heading_params( 'h_' , 'Title Settings' );

	// Default titles
	$cpt_singular_title	= esc_attr__('Portfolio','emphires-addons');
	if( class_exists('Kirki') ){
		// Dynamic Name
		$cpt_singular_title2	= Kirki::get_option( 'portfolio-cpt-singular-title' );
		$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;
	}

	$params = array_merge(

		$heading_options,

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> sprintf( esc_attr__( '%1$s View Style', 'emphires-addons' ) , $cpt_singular_title ) ,
				'description'	=> esc_attr__( 'Select Portfolio view style.', 'emphires-addons' ),
				'param_name'	=> 'style',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('portfolio', true),
				'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
			),
		),

		cspt_vc_box_element_content_params( 'portfolio' )

	);

	return $params;

}

function cspt_vc_portfolio(){

	// Default titles
	$cpt_singular_title	= esc_attr__('Portfolio','emphires-addons');
	if( class_exists('Kirki') ){
		// Dynamic Name
		$cpt_singular_title2	= Kirki::get_option( 'portfolio-cpt-singular-title' );
		$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;
	}

	return array(
		'name'		=> sprintf( esc_attr__( 'CreativesPlanet %1$s Element', 'emphires-addons' ) , $cpt_singular_title ) ,
		'base'		=> 'cspt-portfolio',
		'icon'		=> 'cspt-vc-icon cspt-icon-portfolio',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_portfolio_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_portfolio', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-portfolio', 'cspt_vc_portfolio');
}

