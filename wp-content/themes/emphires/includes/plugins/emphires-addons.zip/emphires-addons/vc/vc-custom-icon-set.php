<?php

// Add font picker setting to icon box module when you select your font family from the dropdown
if( !function_exists('creativesplanet_add_font_picker') ){
function creativesplanet_add_font_picker() {

	// Remove dropdwon icon picker
	vc_remove_param('vc_icon', 'type');
	vc_remove_param('vc_icon', 'icon_fontawesome');
	vc_remove_param('vc_icon', 'icon_openiconic');
	vc_remove_param('vc_icon', 'icon_typicons');
	vc_remove_param('vc_icon', 'icon_entypo');
	vc_remove_param('vc_icon', 'icon_linecons');
	vc_remove_param('vc_icon', 'icon_monosocial');
	vc_remove_param('vc_icon', 'icon_material');

	// Now adding all icon libraries and dropdown again with our own changes.

	/*********************************************************************************************************************/
	/********** [Part 1 - Add new icon library] Add new icon library in "cspt_icon_library_list()" function *********/
	$lib_list_array = cspt_icon_library_list();

	$liblist = array();
	foreach( $lib_list_array as $lib_id=>$lib_data ){
		$liblist[ $lib_data['name'] ] = $lib_id;
	}

	vc_add_param( 'vc_icon', array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'Icon library', 'js_composer' ),
			'weight'		=> 1,
			'value'			=> $liblist,
			'admin_label'	=> true,
			'param_name'	=> 'type',
			'description'	=> esc_attr__( 'Select icon library.', 'js_composer' ),
		)
	);

	/**/
	foreach( $lib_list_array as $lib_id=>$lib_data ){

		$icon_array = array(
			'type'			=> 'iconpicker',
			'heading'		=> esc_attr__( 'Icon', 'js_composer' ),
			'weight'		=> 1,
			'param_name'	=> 'icon_'.$lib_id,
			'value'			=> $lib_data['default_icon'],
			// default value to backend editor admin_label
			'settings'		=> array(
				'emptyIcon'		=> false,
				// default true, display an "EMPTY" icon?
				'type'			=> $lib_id,
				'iconsPerPage'	=> 48,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency'	=> array(
				'element'		=> 'type',
				'value'			=> $lib_id,
			),
			'description'	=> esc_attr__( 'Select icon from library.', 'js_composer' ),
		);

		// Adding icon picker
		vc_add_param( 'vc_icon', $icon_array );

	}

	/*********************************/
	//vc_remove_element( "vc_icon" );

	// creating new VC_ICON element
	/*
	$vc_icon_params = $vc_config_path . '/content/shortcode-vc-icon.php';
	var_dump($vc_icon_params);

	foreach( $vc_icon_params['params'] as $key=>$param ){
		if( $param['param_name']=='type' ){
			unset( $vc_icon_params['params'][$key] );
		}
	}
	*/
	//vc_lean_map( 'vc_icon', null, $vc_icon_params );
	/*********************************/

}
}
//add_filter( 'vc_before_init', 'creativesplanet_add_font_picker', 1 );
//add_filter( 'vc_before_init', 'creativesplanet_add_font_picker', 99 );
add_filter( 'vc_after_init', 'creativesplanet_add_font_picker', 1 );
//add_filter( 'vc_after_init', 'creativesplanet_add_font_picker', 99 );

/*
 *  Ading icon library css files in admin and front website
 */
if( !function_exists('creativesplanet_admin_vc_icon_libraries') ){
function creativesplanet_admin_vc_icon_libraries(){
	// Adding icon libarary
	$lib_list_array = cspt_icon_library_list();
	foreach( $lib_list_array as $lib_id=>$lib_data ){
		wp_enqueue_style( $lib_id, $lib_data['css_path'] );
	}
}
}
add_filter( 'admin_enqueue_scripts', 'creativesplanet_admin_vc_icon_libraries' );

/********************************************************************************************/
/************* [Part 2 - Add new icon library] Create array list here like this *************/

// Add array of your fonts so they can be displayed in the font selector
if( !function_exists('creativesplanet_icon_array_sgicon') ){
function creativesplanet_icon_array_sgicon() {
	return array(
		array('sgicon sgicon-WorldWide'		=> 'WorldWide'),
		array('sgicon sgicon-WorldGlobe'	=> 'WorldGlobe'),
		array('sgicon sgicon-Underpants'	=> 'Underpants'),
		array('sgicon sgicon-Tshirt'		=> 'Tshirt'),
		array('sgicon sgicon-Trousers'		=> 'Trousers'),
		array('sgicon sgicon-Tie'			=> 'Tie'),
		array('sgicon sgicon-TennisBall'	=> 'TennisBall'),
		array('sgicon sgicon-Telesocpe'		=> 'Telesocpe'),
		array('sgicon sgicon-Stop'			=> 'Stop'),
		array('sgicon sgicon-Starship'		=> 'Starship'),
		array('sgicon sgicon-Starship2'		=> 'Starship2'),
		array('sgicon sgicon-Speaker'		=> 'Speaker'),
		array('sgicon sgicon-Speaker2'		=> 'Speaker2'),
		array('sgicon sgicon-Soccer'		=> 'Soccer'),
		array('sgicon sgicon-Snikers'		=> 'Snikers'),
		array('sgicon sgicon-Scisors'		=> 'Scisors'),
		array('sgicon sgicon-Puzzle'		=> 'Puzzle'),
		array('sgicon sgicon-Printer'		=> 'Printer'),
		array('sgicon sgicon-Pool'			=> 'Pool'),
		array('sgicon sgicon-Podium'		=> 'Podium'),
		array('sgicon sgicon-Play'			=> 'Play'),
		array('sgicon sgicon-Planet'		=> 'Planet'),
		array('sgicon sgicon-Pause'			=> 'Pause'),
		array('sgicon sgicon-Next'			=> 'Next'),
		array('sgicon sgicon-MusicNote2'	=> 'MusicNote2'),
		array('sgicon sgicon-MusicNote'		=> 'MusicNote'),
		array('sgicon sgicon-MusicMixer'	=> 'MusicMixer'),
		array('sgicon sgicon-Microphone'	=> 'Microphone'),
		array('sgicon sgicon-Medal'			=> 'Medal'),
		array('sgicon sgicon-ManFigure'		=> 'ManFigure'),
		array('sgicon sgicon-Magnet'		=> 'Magnet'),
		array('sgicon sgicon-Like'			=> 'Like'),
		array('sgicon sgicon-Hanger'		=> 'Hanger'),
		array('sgicon sgicon-Handicap'		=> 'Handicap'),
		array('sgicon sgicon-Forward'		=> 'Forward'),
		array('sgicon sgicon-Footbal'		=> 'Footbal'),
		array('sgicon sgicon-Flag'			=> 'Flag'),
		array('sgicon sgicon-FemaleFigure'	=> 'FemaleFigure'),
		array('sgicon sgicon-Dislike'		=> 'Dislike'),
		array('sgicon sgicon-DiamondRing'	=> 'DiamondRing'),
		array('sgicon sgicon-Cup'			=> 'Cup'),
		array('sgicon sgicon-Crown'			=> 'Crown'),
		array('sgicon sgicon-Column'		=> 'Column'),
		array('sgicon sgicon-Click'			=> 'Click'),
		array('sgicon sgicon-Cassette'		=> 'Cassette'),
		array('sgicon sgicon-Bomb'			=> 'Bomb'),
		array('sgicon sgicon-BatteryLow'	=> 'BatteryLow'),
		array('sgicon sgicon-BatteryFull'	=> 'BatteryFull'),
		array('sgicon sgicon-Bascketball'	=> 'Bascketball'),
		array('sgicon sgicon-Astronaut'		=> 'Astronaut'),
		array('sgicon sgicon-WineGlass'		=> 'WineGlass'),
		array('sgicon sgicon-Water'			=> 'Water'),
		array('sgicon sgicon-Wallet'		=> 'Wallet'),
		array('sgicon sgicon-Umbrella'		=> 'Umbrella'),
		array('sgicon sgicon-TV'			=> 'TV'),
		array('sgicon sgicon-TeaMug'		=> 'TeaMug'),
		array('sgicon sgicon-Tablet'		=> 'Tablet'),
		array('sgicon sgicon-Soda'			=> 'Soda'),
		array('sgicon sgicon-SodaCan'		=> 'SodaCan'),
		array('sgicon sgicon-SimCard'		=> 'SimCard'),
		array('sgicon sgicon-Signal'		=> 'Signal'),
		array('sgicon sgicon-Shaker'		=> 'Shaker'),
		array('sgicon sgicon-Radio'			=> 'Radio'),
		array('sgicon sgicon-Pizza'			=> 'Pizza'),
		array('sgicon sgicon-Phone'			=> 'Phone'),
		array('sgicon sgicon-Notebook'		=> 'Notebook'),
		array('sgicon sgicon-Mug'			=> 'Mug'),
		array('sgicon sgicon-Mastercard'	=> 'Mastercard'),
		array('sgicon sgicon-Ipod'			=> 'Ipod'),
		array('sgicon sgicon-Info'			=> 'Info'),
		array('sgicon sgicon-Icecream2'		=> 'Icecream2'),
		array('sgicon sgicon-Icecream1'		=> 'Icecream1'),
		array('sgicon sgicon-Hourglass'		=> 'Hourglass'),
		array('sgicon sgicon-Help'			=> 'Help'),
		array('sgicon sgicon-Goto'			=> 'Goto'),
		array('sgicon sgicon-Glasses'		=> 'Glasses'),
		array('sgicon sgicon-Gameboy'		=> 'Gameboy'),
		array('sgicon sgicon-ForkandKnife'	=> 'ForkandKnife'),
		array('sgicon sgicon-Export'		=> 'Export'),
		array('sgicon sgicon-Exit'			=> 'Exit'),
		array('sgicon sgicon-Espresso'		=> 'Espresso'),
		array('sgicon sgicon-Drop'			=> 'Drop'),
		array('sgicon sgicon-Download'		=> 'Download'),
		array('sgicon sgicon-Dollars'		=> 'Dollars'),
		array('sgicon sgicon-Dollar'		=> 'Dollar'),
		array('sgicon sgicon-DesktopMonitor'	=> 'DesktopMonitor'),
		array('sgicon sgicon-Corkscrew'		=> 'Corkscrew'),
		array('sgicon sgicon-CoffeeToGo'	=> 'CoffeeToGo'),
		array('sgicon sgicon-Chart'			=> 'Chart'),
		array('sgicon sgicon-ChartUp'		=> 'ChartUp'),
		array('sgicon sgicon-ChartDown'		=> 'ChartDown'),
		array('sgicon sgicon-Calculator'	=> 'Calculator'),
		array('sgicon sgicon-Bread'			=> 'Bread'),
		array('sgicon sgicon-Bourbon'		=> 'Bourbon'),
		array('sgicon sgicon-BottleofWIne'	=> 'BottleofWIne'),
		array('sgicon sgicon-Bag'			=> 'Bag'),
		array('sgicon sgicon-Arrow'			=> 'Arrow'),
		array('sgicon sgicon-Antenna2'		=> 'Antenna2'),
		array('sgicon sgicon-Antenna1'		=> 'Antenna1'),
		array('sgicon sgicon-Anchor'		=> 'Anchor'),
		array('sgicon sgicon-Wheelbarrow'	=> 'Wheelbarrow'),
		array('sgicon sgicon-Webcam'		=> 'Webcam'),
		array('sgicon sgicon-Unlinked'		=> 'Unlinked'),
		array('sgicon sgicon-Truck'			=> 'Truck'),
		array('sgicon sgicon-Timer'			=> 'Timer'),
		array('sgicon sgicon-Time'			=> 'Time'),
		array('sgicon sgicon-StorageBox'	=> 'StorageBox'),
		array('sgicon sgicon-Star'			=> 'Star'),
		array('sgicon sgicon-ShoppingCart'	=> 'ShoppingCart'),
		array('sgicon sgicon-Shield'		=> 'Shield'),
		array('sgicon sgicon-Seringe'		=> 'Seringe'),
		array('sgicon sgicon-Pulse'			=> 'Pulse'),
		array('sgicon sgicon-Plaster'		=> 'Plaster'),
		array('sgicon sgicon-Plaine'		=> 'Plaine'),
		array('sgicon sgicon-Pill'			=> 'Pill'),
		array('sgicon sgicon-PicnicBasket'	=> 'PicnicBasket'),
		array('sgicon sgicon-Phone2'		=> 'Phone2'),
		array('sgicon sgicon-Pencil'		=> 'Pencil'),
		array('sgicon sgicon-Pen'			=> 'Pen'),
		array('sgicon sgicon-PaperClip'		=> 'PaperClip'),
		array('sgicon sgicon-On-Off'		=> 'On-Off'),
		array('sgicon sgicon-Mouse'			=> 'Mouse'),
		array('sgicon sgicon-Megaphone'		=> 'Megaphone'),
		array('sgicon sgicon-Linked'		=> 'Linked'),
		array('sgicon sgicon-Keyboard'		=> 'Keyboard'),
		array('sgicon sgicon-House'			=> 'House'),
		array('sgicon sgicon-Heart'			=> 'Heart'),
		array('sgicon sgicon-Headset'		=> 'Headset'),
		array('sgicon sgicon-FullShoppingCart'	=> 'FullShoppingCart'),
		array('sgicon sgicon-FullScreen'	=> 'FullScreen'),
		array('sgicon sgicon-Folder'		=> 'Folder'),
		array('sgicon sgicon-Floppy'		=> 'Floppy'),
		array('sgicon sgicon-Files'			=> 'Files'),
		array('sgicon sgicon-File'			=> 'File'),
		array('sgicon sgicon-FileBox'		=> 'FileBox'),
		array('sgicon sgicon-ExitFullScreen'	=> 'ExitFullScreen'),
		array('sgicon sgicon-EmptyBox'		=> 'EmptyBox'),
		array('sgicon sgicon-Delete'		=> 'Delete'),
		array('sgicon sgicon-Controller'	=> 'Controller'),
		array('sgicon sgicon-Compass'		=> 'Compass'),
		array('sgicon sgicon-CompassTool'	=> 'CompassTool'),
		array('sgicon sgicon-ClipboardText'	=> 'ClipboardText'),
		array('sgicon sgicon-ClipboardChart'	=> 'ClipboardChart'),
		array('sgicon sgicon-ChemicalGlass'	=> 'ChemicalGlass'),
		array('sgicon sgicon-CD'			=> 'CD'),
		array('sgicon sgicon-Carioca'		=> 'Carioca'),
		array('sgicon sgicon-Car'			=> 'Car'),
		array('sgicon sgicon-Book'			=> 'Book'),
		array('sgicon sgicon-BigTruck'		=> 'BigTruck'),
		array('sgicon sgicon-Bicycle'		=> 'Bicycle'),
		array('sgicon sgicon-Wrench'		=> 'Wrench'),
		array('sgicon sgicon-Web'			=> 'Web'),
		array('sgicon sgicon-Watch'			=> 'Watch'),
		array('sgicon sgicon-Volume'		=> 'Volume'),
		array('sgicon sgicon-Video'			=> 'Video'),
		array('sgicon sgicon-Users'			=> 'Users'),
		array('sgicon sgicon-User'			=> 'User'),
		array('sgicon sgicon-UploadCLoud'	=> 'UploadCLoud'),
		array('sgicon sgicon-Typing'		=> 'Typing'),
		array('sgicon sgicon-Tools'			=> 'Tools'),
		array('sgicon sgicon-Tag'			=> 'Tag'),
		array('sgicon sgicon-Speedometter'	=> 'Speedometter'),
		array('sgicon sgicon-Share'			=> 'Share'),
		array('sgicon sgicon-Settings'		=> 'Settings'),
		array('sgicon sgicon-Search'		=> 'Search'),
		array('sgicon sgicon-Screwdriver'	=> 'Screwdriver'),
		array('sgicon sgicon-Rolodex'		=> 'Rolodex'),
		array('sgicon sgicon-Ringer'		=> 'Ringer'),
		array('sgicon sgicon-Resume'		=> 'Resume'),
		array('sgicon sgicon-Restart'		=> 'Restart'),
		array('sgicon sgicon-PowerOff'		=> 'PowerOff'),
		array('sgicon sgicon-Pointer'		=> 'Pointer'),
		array('sgicon sgicon-Picture'		=> 'Picture'),
		array('sgicon sgicon-OpenedLock'	=> 'OpenedLock'),
		array('sgicon sgicon-Notes'			=> 'Notes'),
		array('sgicon sgicon-Mute'			=> 'Mute'),
		array('sgicon sgicon-Movie'			=> 'Movie'),
		array('sgicon sgicon-Microphone2'	=> 'Microphone2'),
		array('sgicon sgicon-Message'		=> 'Message'),
		array('sgicon sgicon-MessageRight'	=> 'MessageRight'),
		array('sgicon sgicon-MessageLeft'	=> 'MessageLeft'),
		array('sgicon sgicon-Menu'			=> 'Menu'),
		array('sgicon sgicon-Media'			=> 'Media'),
		array('sgicon sgicon-Mail'			=> 'Mail'),
		array('sgicon sgicon-List'			=> 'List'),
		array('sgicon sgicon-Layers'		=> 'Layers'),
		array('sgicon sgicon-Key'			=> 'Key'),
		array('sgicon sgicon-Imbox'			=> 'Imbox'),
		array('sgicon sgicon-Eye'			=> 'Eye'),
		array('sgicon sgicon-Edit'			=> 'Edit'),
		array('sgicon sgicon-DSLRCamera'	=> 'DSLRCamera'),
		array('sgicon sgicon-DownloadCloud'	=> 'DownloadCloud'),
		array('sgicon sgicon-CompactCamera'	=> 'CompactCamera'),
		array('sgicon sgicon-Cloud'			=> 'Cloud'),
		array('sgicon sgicon-ClosedLock'	=> 'ClosedLock'),
		array('sgicon sgicon-Chart2'		=> 'Chart2'),
		array('sgicon sgicon-Bulb'			=> 'Bulb'),
		array('sgicon sgicon-Briefcase'		=> 'Briefcase'),
		array('sgicon sgicon-Blog'			=> 'Blog'),
		array('sgicon sgicon-Agenda'		=> 'Agenda'),
	);
}
}
add_filter( 'vc_iconpicker-type-sgicon', 'creativesplanet_icon_array_sgicon' );

// Add array of your fonts so they can be displayed in the font selector
if( !function_exists('creativesplanet_icon_array_cspt_emphires_icon') ){
	function creativesplanet_icon_array_cspt_emphires_icon() {
		return array(
			array('cspt-emphires-icon cspt-emphires-icon-call' => 'call'),
			array('cspt-emphires-icon cspt-emphires-icon-pdf' => 'pdf'),
			array('cspt-emphires-icon cspt-emphires-icon-document' => 'document'),
			array('cspt-emphires-icon cspt-emphires-icon-placeholder' => 'placeholder'),
			array('cspt-emphires-icon cspt-emphires-icon-placeholder-1' => 'placeholder-1'),
			array('cspt-emphires-icon cspt-emphires-icon-email' => 'email'),
			array('cspt-emphires-icon cspt-emphires-icon-hr' => 'hr'),
			array('cspt-emphires-icon cspt-emphires-icon-consultation' => 'consultation'),
			array('cspt-emphires-icon cspt-emphires-icon-hr-1' => 'hr-1'),
			array('cspt-emphires-icon cspt-emphires-icon-consulting' => 'consulting'),
			array('cspt-emphires-icon cspt-emphires-icon-job-interview' => 'job-interview'),
			array('cspt-emphires-icon cspt-emphires-icon-right-arrow' => 'right-arrow'),
			array('cspt-emphires-icon cspt-emphires-icon-arrow' => 'arrow'),
			array('cspt-emphires-icon cspt-emphires-icon-appointment' => 'appointment'),
			array('cspt-emphires-icon cspt-emphires-icon-placeholder-2' => 'placeholder-2'),
			array('cspt-emphires-icon cspt-emphires-icon-support' => 'support'),
			array('cspt-emphires-icon cspt-emphires-icon-telephone' => 'telephone'),
			array('cspt-emphires-icon cspt-emphires-icon-paper-plane' => 'paper-plane'),
			array('cspt-emphires-icon cspt-emphires-icon-buy' => 'buy'),
			array('cspt-emphires-icon cspt-emphires-icon-management' => 'management'),
			array('cspt-emphires-icon cspt-emphires-icon-search-engine' => 'search-engine'),
			array('cspt-emphires-icon cspt-emphires-icon-crm' => 'crm'),
			array('cspt-emphires-icon cspt-emphires-icon-businessman' => 'businessman'),
			array('cspt-emphires-icon cspt-emphires-icon-content' => 'content'),
			array('cspt-emphires-icon cspt-emphires-icon-setting' => 'setting'),
			array('cspt-emphires-icon cspt-emphires-icon-funnel' => 'funnel'),
			array('cspt-emphires-icon cspt-emphires-icon-goal' => 'goal'),
			array('cspt-emphires-icon cspt-emphires-icon-process' => 'process'),
			array('cspt-emphires-icon cspt-emphires-icon-team' => 'team'),
			array('cspt-emphires-icon cspt-emphires-icon-customer-service' => 'customer-service'),
			array('cspt-emphires-icon cspt-emphires-icon-trophy' => 'trophy'),
			array('cspt-emphires-icon cspt-emphires-icon-shield' => 'shield'),
			array('cspt-emphires-icon cspt-emphires-icon-risk' => 'risk'),
			array('cspt-emphires-icon cspt-emphires-icon-diamond' => 'diamond'),
			array('cspt-emphires-icon cspt-emphires-icon-research' => 'research'),
			array('cspt-emphires-icon cspt-emphires-icon-metrics' => 'metrics'),
			array('cspt-emphires-icon cspt-emphires-icon-research-and-development' => 'research-and-development'),
			array('cspt-emphires-icon cspt-emphires-icon-megaphone' => 'megaphone'),
			array('cspt-emphires-icon cspt-emphires-icon-call-center' => 'call-center'),
			array('cspt-emphires-icon cspt-emphires-icon-maintenance' => 'maintenance'),
			array('cspt-emphires-icon cspt-emphires-icon-invest' => 'invest'),
			array('cspt-emphires-icon cspt-emphires-icon-budget' => 'budget'),
			array('cspt-emphires-icon cspt-emphires-icon-punctuality' => 'punctuality'),			
			array('cspt-emphires-icon cspt-emphires-icon-deal' => 'deal'),
			array('cspt-emphires-icon cspt-emphires-icon-affiliate' => 'affiliate'),
			array('cspt-emphires-icon cspt-emphires-icon-interview' => 'interview'),
			array('cspt-emphires-icon cspt-emphires-icon-system' => 'system'),
			array('cspt-emphires-icon cspt-emphires-icon-growth' => 'growth'),
			array('cspt-emphires-icon cspt-emphires-icon-strategy' => 'strategy'),
			array('cspt-emphires-icon cspt-emphires-icon-interview-1' => 'interview-1'),
			array('cspt-emphires-icon cspt-emphires-icon-supplier' => 'supplier'),
			array('cspt-emphires-icon cspt-emphires-icon-application' => 'application'),
			array('cspt-emphires-icon cspt-emphires-icon-employment' => 'employment'),
			array('cspt-emphires-icon cspt-emphires-icon-sedentary' => 'sedentary'),
			array('cspt-emphires-icon cspt-emphires-icon-application-1' => 'application-1'),
			array('cspt-emphires-icon cspt-emphires-icon-people' => 'people'),
			array('cspt-emphires-icon cspt-emphires-icon-trainee' => 'trainee'),
			array('cspt-emphires-icon cspt-emphires-icon-unemployment' => 'unemployment'),
			array('cspt-emphires-icon cspt-emphires-icon-digital-assistant' => 'digital-assistant'),
			array('cspt-emphires-icon cspt-emphires-icon-podium' => 'podium'),
			array('cspt-emphires-icon cspt-emphires-icon-digital-strategy' => 'digital-strategy'),
			array('cspt-emphires-icon cspt-emphires-icon-checked' => 'checked'),
		);
	}
	}
	add_filter( 'vc_iconpicker-type-cspt_emphires_icon', 'creativesplanet_icon_array_cspt_emphires_icon' );

/***************************************************************************************************/
/******************* [Part 3 - Add new icon library] Create JS array in this file ******************/
// Edit /plugins/emphires-addons/customizer/creativesplanet-icon-picker/creativesplanet-icon-picker.js file

