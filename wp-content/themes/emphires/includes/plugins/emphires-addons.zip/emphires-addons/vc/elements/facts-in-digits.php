<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_facts_in_digits_params(){

	$icons_params = vc_map_integrate_shortcode( 'vc_icon', 'i_', esc_attr__('Icon','emphires-addons'), array(
		'include_only_regex' => '/^(type|icon_\w*)/',
		// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
	), array(
		'element' => 'boxstyle',
		'value' => array('top-rounded-icon','left-icon','top-big-icon'),
	) );

	$icons_params_new = array();

	/* Adding class for two column */
	foreach( $icons_params as $param ){
		$icons_params_new[] = $param;
	}

	$allParams = array(

		array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__( 'Facts In Digits View Style', 'emphires-addons' ),
			'description'	=> esc_attr__( 'Select Facts In Digits view style.', 'emphires-addons' ),
			'param_name'	=> 'style',
			'std'			=> '1',
			'value'			=> cspt_element_template_list('facts-in-digits', true),
			'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
		),

		array(
			'type'			=> 'textfield',
			'holder'		=> 'div',
			'class'			=> '',
			'heading'		=> esc_attr__('Heading Text', 'emphires-addons'),
			'param_name'	=> 'title',
			'std'			=> esc_attr__('Title Text', 'emphires-addons'),
			'description'	=> esc_attr__('Enter text for the title. Leave blank if no title is needed.', 'emphires-addons'),
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),

		array(
			'type'				=> 'textfield',
			'holder'			=> 'div',
			'class'				=> '',
			'heading'			=> esc_attr__('Rotating Number', 'emphires-addons'),
			'param_name'		=> 'digit',
			'std'				=> '85',
			'description'		=> esc_attr__('Enter rotating number digit here.', 'emphires-addons'),
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'				=> 'textfield',
			'holder'			=> 'div',
			'heading'			=> esc_attr__('Text Before Number', 'emphires-addons'),
			'param_name'		=> 'before',
			'description'		=> esc_attr__('Enter text which appear just before the rotating numbers.', 'emphires-addons'),
			'edit_field_class'	=> 'vc_col-sm-6 vc_column',
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"heading"		=> esc_attr__("Text Style",'emphires-addons'),
			"param_name"	=> "beforetextstyle",
			"description"	=> esc_attr__('Select text style for the text.', 'emphires-addons') . '<br>' . esc_attr__('Superscript text appears half a character above the normal line, and is rendered in a smaller font.','emphires-addons') . '<br>' . esc_attr__('Subscript text appears half a character below the normal line, and is sometimes rendered in a smaller font.','emphires-addons'),
			'value' => array(
				esc_attr__( 'Superscript', 'emphires-addons' ) => 'sup',
				esc_attr__( 'Subscript', 'emphires-addons' )   => 'sub',
				esc_attr__( 'Normal', 'emphires-addons' )      => 'span',
			),
			'std' => 'sup',
			'edit_field_class'	=> 'vc_col-sm-6 vc_column',
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'				=> 'textfield',
			'holder'			=> 'div',
			'class'				=> '',
			'heading'			=> esc_attr__('Text After Number', 'emphires-addons'),
			'param_name'		=> 'after',
			'description'		=> esc_attr__('Enter text which appear just after the rotating numbers.', 'emphires-addons'),
			'edit_field_class'	=> 'vc_col-sm-6 vc_column',
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class"			=> "",
			"heading"		=> esc_attr__("Text Style",'emphires-addons'),
			"param_name"	=> "aftertextstyle",
			"description"	=> esc_attr__('Select text style for the text.', 'emphires-addons') . '<br>' . esc_attr__('Superscript text appears half a character above the normal line, and is rendered in a smaller font.','emphires-addons') . '<br>' . esc_attr__('Subscript text appears half a character below the normal line, and is sometimes rendered in a smaller font.','emphires-addons'),
			'value' => array(
				esc_attr__( 'Superscript', 'emphires-addons' ) => 'sup',
				esc_attr__( 'Subscript', 'emphires-addons' )   => 'sub',
				esc_attr__( 'Normal', 'emphires-addons' )      => 'span',
			),
			'std' => 'sub',
			'edit_field_class'	=> 'vc_col-sm-6 vc_column',
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'			=> 'textfield',
			'holder'		=> 'div',
			'class'			=> '',
			'heading'		=> esc_attr__('Rotating digit Interval', 'emphires-addons'),
			'param_name'	=> 'interval',
			'std'			=> '5',
			'description'	=> esc_attr__('Enter rotating interval number here.', 'emphires-addons'),
			'group'		    => esc_attr__( 'Content', 'emphires-addons' ),
		)
	);

	// merging all options
	$params = array_merge( $allParams, $icons_params_new );

	// merging extra options like css animation, css options etc
	$params = array_merge(

		$params,

		array(

			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'Content', 'emphires-addons' ),) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		array(
			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)
		//array( $extra_class ),
		//array( cspt_vc_ele_css_editor_option() )
	);

	return $params;

}

function cspt_vc_facts_in_digits(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Facts In Digits Element', 'emphires-addons' ),
		'base'		=> 'cspt-facts-in-digits',
		'icon'		=> 'cspt-vc-icon cspt-icon-facts-in-digits',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_facts_in_digits_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_facts_in_digits', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-facts-in-digits', 'cspt_vc_facts_in_digits');
}

