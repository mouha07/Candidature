/*
function creativesplanet_imgselector_callback(){
	jQuery('.creativesplanet_imgselector').change(function() {      // When arrow is clicked
		var currval = jQuery(this).val();
		var wrapper = jQuery(this).parent();
		jQuery( '.cspt-imgselector-thumb', wrapper).removeClass('cspt-imgselector-thumb-selected');
		jQuery( '.cspt-imgselector-thumb-'+currval, wrapper).addClass('cspt-imgselector-thumb-selected');
	});
};
creativesplanet_imgselector_callback();
*/	

function creativesplanet_imgselector_click(){
	jQuery('.cspt-imgselector-thumb').each(function(){
		var $this = jQuery(this);

		jQuery($this).on( 'click', function(){

			var currval = jQuery(this).data('value');
			var wrapper = jQuery(this).closest('.cspt-imgselector-main-wrapper');

			jQuery( '.cspt-imgselector-thumb', wrapper).removeClass('cspt-imgselector-thumb-selected');
			jQuery( '.cspt-imgselector-thumb-'+currval, wrapper).addClass('cspt-imgselector-thumb-selected');

			jQuery( 'select', wrapper).val(currval).trigger('change');

		});

	});

};
creativesplanet_imgselector_click();