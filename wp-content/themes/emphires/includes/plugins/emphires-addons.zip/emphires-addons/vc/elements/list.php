<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_list_params(){

	$params = array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'List Type', 'emphires-addons' ),
			'param_name'	=> 'type',
			'value'			=> array(
				esc_attr__( 'None', 'emphires-addons' )	=> 'none',
				esc_attr__( 'Bullet (disc)', 'emphires-addons' )	=> 'disc',
				esc_attr__( 'Icon', 'emphires-addons' )	=> 'icon',
			),
			'std'			=> 'icon',
			'description'	=> esc_attr__( 'Select list style.', 'emphires-addons' ),
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),

		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 1','emphires-addons' ),
			'param_name'  => 'line_1',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 2','emphires-addons' ),
			'param_name'  => 'line_2',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 3','emphires-addons' ),
			'param_name'  => 'line_3',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 4','emphires-addons' ),
			'param_name'  => 'line_4',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 5','emphires-addons' ),
			'param_name'  => 'line_5',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 6','emphires-addons' ),
			'param_name'  => 'line_6',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 7','emphires-addons' ),
			'param_name'  => 'line_7',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 8','emphires-addons' ),
			'param_name'  => 'line_8',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 9','emphires-addons' ),
			'param_name'  => 'line_9',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),
		array(
			'type'        => 'textarea_raw_html',
			'heading'     => esc_attr__( 'List Line 10','emphires-addons' ),
			'param_name'  => 'line_10',
			'description' => esc_attr__( 'Enter text for the list line.', 'emphires-addons' ),
			'std'         => '',
			'value'       => '',
			'param_holder_class' => 'cspt-vc-textarea',
			'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		),

		/*
		array(
			'type'					=> 'dropdown',
			'heading'				=> esc_attr__( 'List icon color', 'emphires-addons' ),
			'param_name'			=> 'icon_color',
			'value'					=> cspt_getVcShared( 'colors' ),
			'std'					=> 'globalcolor',
			'description'			=> esc_attr__( 'Select icon color for list.', 'emphires-addons' ),
			'param_holder_class'	=> 'cspt_vc_colored-dropdown',
			'edit_field_class'		=> 'vc_col-sm-6 vc_column',
		),
		array(
			'type'					=> 'dropdown',
			'heading'				=> esc_attr__('Text Color', 'emphires-addons'),
			'description'			=> esc_attr__('Select text color.', 'emphires-addons'),
			'param_name'			=> 'cspt_textcolor',
			'value'					=> array( esc_attr__( 'Default', 'emphires-addons' ) => '' ) + cspt_getVcShared( 'colors' ),
			'param_holder_class'	=> 'cspt_vc_colored-dropdown',
			'edit_field_class'		=> 'vc_col-sm-6 vc_column',
		),
		*/

		/*
		array(
			'type'			=> 'dropdown',
			'heading'		=> esc_attr__( 'List Font size', 'emphires-addons' ),
			'param_name'	=> 'textsize',
			'value'			=> array(
				esc_attr__( 'Default', 'emphires-addons' )		=> '',
				esc_attr__( 'Small', 'emphires-addons' )			=> 'small',
				esc_attr__( 'Medium', 'emphires-addons' )			=> 'medium',
				esc_attr__( 'Large', 'emphires-addons' )			=> 'large',
			),
			'std'			=> '',
			'description'	=> esc_attr__( 'Select list font size. This will also apply to icon too', 'emphires-addons' ),
		),
		*/

	);

	$icon_options = vc_map_integrate_shortcode( 'vc_icon', 'i_', esc_attr__( 'Icon', 'emphires-addons' ), array(
		'include_only_regex' => '/^(type|icon_\w*)/',
		// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
		), array(
			'element'	=> 'type',
			'value'		=> 'icon',
		)
	);

	// Setting default icon for Font Awesome icon
	foreach( $icon_options as $i=>$icon ){
		if( !empty($icon['param_name']) && $icon['param_name']=='i_icon_fontawesome' ){
			$icon_options[$i]['value'] = 'fa fa-caret-right';
		}
	}

	// merging extra options like css animation, css options etc
	$params = array_merge(

		$params,

		$icon_options,

		array(

			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'Content', 'emphires-addons' ),) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		array( array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
		) )
	);

	return $params;

}

function cspt_vc_list(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet List Element', 'emphires-addons' ),
		'base'		=> 'cspt-list',
		'icon'		=> 'cspt-vc-icon cspt-icon-list',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_list_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_list', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-list', 'cspt_vc_list');
}

