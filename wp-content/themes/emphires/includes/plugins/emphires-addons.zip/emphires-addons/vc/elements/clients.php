<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_client_params(){

	$heading_options = cspt_vc_heading_params( 'h_' , 'Title Settings' );

	$params = array_merge(

		$heading_options,

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> esc_attr__( 'Clients View Style', 'emphires-addons' ),
				'description'	=> esc_attr__( 'Select Clients view style.', 'emphires-addons' ),
				'param_name'	=> 'style',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('client', true),
				'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
			),
		),

		cspt_vc_box_element_content_params( 'client' )

	);

	// Change default value
	/*
	foreach ( $params as $key => $val ) {
		if( isset($val['param_name']) && $val['param_name']=='h2_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='h4_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='i_type' ){
			$params[ $key ]['std'] = 'fontawesome';
		} else if( isset($val['param_name']) && $val['param_name']=='h2' ){
			$params[ $key ]['std'] = esc_attr__('This is heading', 'emphires-addons');
		} else if( isset($val['param_name']) && $val['param_name']=='content' ){
			$params[ $key ]['std'] = '';
		}

	}
	*/

	return $params;

}

function cspt_vc_client(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Client Logo Element', 'emphires-addons' ),
		'base'		=> 'cspt-client',
		'icon'		=> 'cspt-vc-icon cspt-icon-client',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_client_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_client', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-client', 'cspt_vc_client');
}

