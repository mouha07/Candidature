<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_iconheading_params(){

	$heading_params = cspt_vc_heading_params();

	foreach( $heading_params as $key=>$param ){
		if( !empty($param['param_name']) && $param['param_name']=='align' ){
			unset($heading_params[$key]);
		}
	}

	$params = array_merge(

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> esc_attr__( 'Icon Heading Style', 'emphires-addons' ),
				'description'	=> esc_attr__( 'Select Icon Heading style.', 'emphires-addons' ),
				'param_name'	=> 'boxstyle',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('icon-heading', true),
				'group'			=> esc_attr__( 'Box Style', 'emphires-addons' ),
			),
		),

		array(
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_attr__( 'Icon', 'emphires-addons' ),
				'description'	=> esc_attr__( 'Show/hide icon or show text (in place of icon).', 'emphires-addons' ),
				'param_name'	=> 'icon_type',
				'std'			=> 'icon',
				'value'			=> array(
					esc_attr__( 'Show icon', 'emphires-addons' )					=> 'icon',
					esc_attr__( 'No icon', 'emphires-addons' )						=> 'none',
					esc_attr__( 'Show text in place of icon', 'emphires-addons' )	=> 'text',
					esc_attr__( 'Show image in place of icon', 'emphires-addons' )	=> 'image',
				),
				'group'			=> esc_attr__( 'Icon', 'emphires-addons' ),
			),
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_attr__( 'Select Image', 'emphires-addons' ),
				'param_name'	=> 'icon_image',
				'description'	=> esc_attr__( 'Select image which used in place of icon.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Icon', 'emphires-addons' ),
				'dependency' 	=> array(
					'element'		=> 'icon_type',
					'value'			=> array('image'),
				)
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Text', 'emphires-addons' ),
				'param_name'	=> 'small_text',
				'value'			=> '01',
				'description'	=> esc_attr__( 'This text will appear in place of icon. This is useful if you like to show small text like "01" or "Hi" small texts.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Icon', 'emphires-addons' ),
				'dependency' 	=> array(
					'element'		=> 'icon_type',
					'value'			=> array('text'),
				)
			),
		),

		vc_map_integrate_shortcode( 'vc_icon', 'i_', esc_attr__( 'Icon', 'emphires-addons' ), array(
			'include_only_regex' => '/^(type|icon_\w*)/',
			// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
			), array(
				'element' => 'icon_type',
				'value'     => 'icon',
			)
		),

		$heading_params,

		array(
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_attr__( 'Add button', 'emphires-addons' ) . '?',
				'description'	=> esc_attr__( 'Add button for call to action.', 'emphires-addons' ),
				'param_name'	=> 'add_button',
				'value'			=> array(
					esc_attr__( 'No', 'emphires-addons' )	=> '',
					esc_attr__( 'Yes', 'emphires-addons' )	=> 'yes',
				),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
		),

		vc_map_integrate_shortcode( 'vc_btn', 'btn_', esc_attr__( 'Button', 'emphires-addons' ), array(
			'exclude' => array( 'css', 'style', 'shape', 'color', 'size', 'align', 'el_id', 'el_class', 'gradient_color_1', 'gradient_color_2', 'gradient_custom_color_1', 'gradient_custom_color_2', 'gradient_text_color', 'custom_background', 'custom_text', 'outline_custom_color', 'outline_custom_hover_background', 'outline_custom_hover_text', 'button_block' ),
			), array(
				'element' => 'add_button',
				'not_empty' => true,
			)
		),

		array(
			cspt_vc_map_add_css_animation( array('group'=>'Content') ),
		),

		array(

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'emphires-addons' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)

	);

	// Change default value
	foreach ( $params as $key => $val ) {
		if( isset($val['param_name']) && $val['param_name']=='h2_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='h4_use_theme_fonts' ){
			$params[ $key ]['std'] = 'yes';
		} else if( isset($val['param_name']) && $val['param_name']=='i_type' ){
			$params[ $key ]['std'] = 'fontawesome';
		} else if( isset($val['param_name']) && $val['param_name']=='h2' ){
			$params[ $key ]['std'] = esc_attr__('This is heading', 'emphires-addons');
		} else if( isset($val['param_name']) && $val['param_name']=='description' ){
			$params[ $key ]['std'] = '';
		}

	}

	return $params;

}

function cspt_vc_iconheading(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Icon Heading Element', 'emphires-addons' ),
		'base'		=> 'cspt-icon-heading',
		'icon'		=> 'cspt-vc-icon cspt-icon-ihbox',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_iconheading_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_iconheading', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-icon-heading', 'cspt_vc_iconheading');
}

