<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_static_content_params(){

	$heading_options = cspt_vc_heading_params( 'h_' , 'Title Settings' );

	$params = array_merge(

		$heading_options,

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> esc_attr__( 'Static Box View Style', 'emphires-addons' ),
				'description'	=> esc_attr__( 'Select Static Box view style.', 'emphires-addons' ),
				'param_name'	=> 'style',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('static-box', true),
				'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
			),
		),

		array(
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Box Image size', 'emphires-addons' ),
				'param_name'	=> 'img_size',
				'value'			=> 'full',
				'description'	=> '<strong>'.esc_attr__( 'NOTE:', 'emphires-addons' ) . '</strong> ' . esc_attr__( 'This is common for all images in all boxes. This will apply to all images in all boxes.', 'emphires-addons' ) . '<br>' . esc_attr__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Box Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_attr__( 'Boxes', 'emphires-addons' ),
				'param_name'	=> 'values',
				'description'	=> esc_attr__( 'Enter values for graph - value, title and color.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Box Content', 'emphires-addons' ),
				'value' => urlencode( json_encode( array(
					array(
						'attach_image'	=> '',
						'label'			=> esc_attr('Surgical Procedures'),
						'smalltext'		=> esc_attr('Doctor Timetable Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.'),
					),
					array(
						'attach_image'	=> '',
						'label'			=> esc_attr('Refractive Nature'),
						'smalltext'		=> esc_attr('Doctor Timetable Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.'),
					),
					array(
						'attach_image'	=> '',
						'label'			=> esc_attr('Transitions Lenses'),
						'smalltext'		=> esc_attr('Doctor Timetable Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.'),
					),
				) ) ),
				'params' => array(
					array(
						'type' => 'attach_image',
						'heading' => esc_attr__( 'Box Image', 'emphires-addons' ),
						'param_name' => 'boximage',
						'description' => esc_attr__( 'Select image.', 'emphires-addons' ),
						'admin_label' => true,
						'edit_field_class'	=> 'vc_col-sm-4 vc_column',
					),

					array(
						'type' => 'textfield',
						'heading' => esc_attr__( 'Box Title', 'emphires-addons' ),
						'param_name' => 'label',
						'description' => esc_attr__( 'Enter text used as title of bar.', 'emphires-addons' ),
						'admin_label' => true,

					),
					array(
						'type' => 'textarea',
						'heading' => esc_attr__( 'Highlight Text', 'emphires-addons' ),
						'param_name' => 'smalltext',
						'description' => esc_attr__( 'Enter small text. This text will appear on image.', 'emphires-addons' ),
						'admin_label' => true,
					),
				),
			),
		),

		array(
			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'Box Content', 'emphires-addons' ) ) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'Box Content', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Box Content', 'emphires-addons' ),
			),
		),

		cspt_vc_box_element_appearance_params( esc_attr__('Staic Box', 'emphires-addons') ),

		array(

			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)

	);

	return $params;

}

function cspt_vc_static_content(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Static Box Element', 'emphires-addons' ),
		'base'		=> 'cspt-static-box',
		'icon'		=> 'cspt-vc-icon cspt-icon-static-box',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_static_content_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_static_content', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-static-box', 'cspt_vc_static_content');
}

