<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_pricing_table_params(){

	$group_params = array(
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_attr__( 'Label', 'emphires-addons' ),
			'param_name'	=> 'label',
			'description'	=> esc_attr__( 'Enter text used as title of bar. You can use STRONG tag to bold some texts.', 'emphires-addons' ),
			'admin_label'	=> true,
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_attr__( 'Icon Class (Optional)', 'emphires-addons' ),
			'param_name'	=> 'icon_class',
			'description'	=> esc_attr__( '(Optional) Enter class for icon that appear. Leave blank for default icon.', 'emphires-addons' ),
			'admin_label'	=> true,
		),

	);

	// Merging icon with other options
	//$params_group_array = array_merge( $group_params, $group_icon );
	$params_group_array = $group_params;

	/*** Coumn Options ***/
	$params_heading =  array(
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_attr__( 'Heading', 'emphires-addons' ),
			'param_name'	=> 'heading',
			'description'	=> esc_attr__( 'Enter text used as main heading. This will be plan title like "Basic", "Pro" etc.', 'emphires-addons' ),
			//'group'			=> esc_attr__( 'Content', 'emphires-addons' ),
		)
	);

	// Main Icon picker
	$main_icon = vc_map_integrate_shortcode( 'vc_icon', 'i_', esc_attr__( 'Content', 'emphires-addons' ),
		array(
			'include_only_regex' => '/^(type|icon_\w*)/',
			// we need only type, icon_fontawesome, icon_blabla..., NOT color and etc
		)
	);

	$params_price =  array(
		array(
			'type'				=> 'textfield',
			'heading'			=> esc_attr__( 'Price', 'emphires-addons' ),
			'param_name'		=> 'price',
			'std'				=> '100',
			'description'		=> esc_attr__( 'Enter Price.', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-3 vc_column',
		),

		array(
			'type'				=> 'textfield',
			'heading'			=> esc_attr__( 'Currency symbol', 'emphires-addons' ),
			'param_name'		=> 'cur_symbol',
			'std'				=> '$',
			'description'		=> esc_attr__( 'Enter currency symbol', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-3 vc_column',
		),
		array(
			'type'				=> 'dropdown',
			'heading'			=> esc_attr__( 'Currency Symbol position', 'emphires-addons' ),
			'param_name'		=> 'cur_symbol_position',
			'std'				=> 'after',
			'value'				=> array(
				esc_attr__( 'Before price', 'emphires-addons' )	=> 'before',
				esc_attr__( 'After price', 'emphires-addons' )	=> 'after',
			),
			'description'		=> esc_attr__( 'Select currency position.', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-3 vc_column',
		),
		array(
			'type'				=> 'textfield',
			'heading'			=> esc_attr__( 'Price Frequency', 'emphires-addons' ),
			'param_name'		=> 'price_frequency',
			'std'				=> esc_attr__( 'Monthly', 'emphires-addons' ),
			'description'		=> esc_attr__( 'Enter currency frequency like "Monthly", "Yearly" or "Weekly" etc.', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-3 vc_column',
		),
	);

	$params_btn = array(
		array(
			'type'       		=> 'textfield',
			'heading'    		=> esc_attr__( 'Button Text', 'emphires-addons' ),
			'param_name' 		=> 'btn_title',
			'edit_field_class'	=> 'vc_col-sm-3 vc_column',
		),
		array(
			'type'				=> 'vc_link',
			'heading'			=> esc_attr__( 'Button URL (Link)', 'emphires-addons' ),
			'param_name'		=> 'btn_link',
			'description'		=> esc_attr__( 'Add link to button.', 'emphires-addons' ),
			'edit_field_class'	=> 'vc_col-sm-9 vc_column',
		),
	);

	$params_lines =  array(
		array(
			'type'			=> 'param_group',
			'heading'		=> esc_attr__( 'Each Line (Features)', 'emphires-addons' ),
			'param_name'	=> 'values',
			'description'	=> esc_attr__( 'Enter values for graph - value, title and color.', 'emphires-addons' ),
			'value'			=> '',

			'value'			=> urlencode( json_encode( array(
				array(
					'label'			=> esc_attr__( 'This is label one', 'emphires-addons' ),
					'icon_class'	=> '',
				),
				array(
					'label'			=> esc_attr__( 'This is label two', 'emphires-addons' ),
					'icon_class'	=> '',
				),
				array(
					'label'			=> esc_attr__( 'This is label three', 'emphires-addons' ),
					'icon_class'	=> '',
				),
			) ) ),

			'params'		=> $params_group_array,
		),

	);

	$params_all = array_merge(
		//$params_boxstyle,
		$params_heading,
		$main_icon,
		$params_price,
		$params_btn,
		$params_lines
	);

	/**** Multiple Columns for pricing table ****/
	$params = array();

	for( $i=1; $i<=5; $i++ ){  // 3 column

		$tab_title = esc_attr__('First Column','emphires-addons');
		switch( $i ){
			case 2:
				$tab_title = esc_attr__('Second Column','emphires-addons');
				break;
			case 3:
				$tab_title = esc_attr__('Third Column','emphires-addons');
				break;
			case 4:
				$tab_title = esc_attr__('Fourth Column','emphires-addons');
				break;
			case 5:
				$tab_title = esc_attr__('Fifth Column','emphires-addons');
				break;
		}

		foreach( $params_all as $param ){

			if( !empty($param['param_name']) ){
				$param['param_name'] = 'col'.$i.'_'.$param['param_name'];
			}
			$param['group']      = $tab_title;

			if( !empty($param['dependency']) && !empty($param['dependency']["element"]) ){
				$param['dependency']["element"] = 'col'.$i.'_'.$param['dependency']["element"];
			}

			$params[] = $param;

		}

	} // for

	$params = array_merge(

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> esc_attr__( 'View Style', 'emphires-addons' ),
				'description'	=> esc_attr__( 'Select Pricing Table view style.', 'emphires-addons' ),
				'param_name'	=> 'style',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('pricing-table', true),
				'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
			),
		),

		array(

			array(
				'type'				=> 'dropdown',
				'heading'			=> esc_attr__( 'Featured Column', 'emphires-addons' ),
				'param_name'		=> 'featured_col',
				//'std'				=> '',
				'value'				=> array(
					esc_attr__( 'None', 'emphires-addons' )		=> '',
					esc_attr__( '1st Column', 'emphires-addons' )	=> '1',
					esc_attr__( '2nd Column', 'emphires-addons' )	=> '2',
					esc_attr__( '3rd Column', 'emphires-addons' )	=> '3',
					esc_attr__( '4th Column', 'emphires-addons' )	=> '4',
					esc_attr__( '5th Column', 'emphires-addons' )	=> '5',
				),
				'description'		=> esc_attr__( 'Select whith column will be with featured style.', 'emphires-addons' ),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Featured Text', 'emphires-addons' ),
				'std'			=> esc_attr__( 'Featured', 'emphires-addons' ),
				'param_name'	=> 'featured_text',
				'description'	=> esc_attr__( 'Enter text that will be shown for featured column. Example "Featured".', 'emphires-addons' ),
				'dependency' => array(
					'element' => 'featured_col',
					'value' => array( '1', '2', '3', '4', '5' ),
				),
				'edit_field_class'	=> 'vc_col-sm-6 vc_column',
				'group'				=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),

		),

		array(
			cspt_vc_map_add_css_animation( array('group' => esc_attr__( 'General Settings', 'emphires-addons' ),) ),

			array(
				'type'			=> 'el_id',
				'heading'		=> esc_attr__( 'Element ID', 'emphires-addons' ),
				'param_name'	=> 'el_id',
				'description'	=> sprintf( esc_attr__( 'Enter element ID (Note: make sure it is unique and valid according to %1$s w3c specification%2$s).', 'emphires-addons' ), '<a href="http://www.w3schools.com/tags/att_global_id.asp" target="_blank">', '</a>' ),
				'group'			=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( 'Extra class name', 'emphires-addons' ),
				'param_name'	=> 'el_class',
				'description'	=> esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'General Settings', 'emphires-addons' ),
			),
		),

		$params,

		array(

			array(
				'type'			=> 'css_editor',
				'heading'		=> esc_attr__( 'CSS box', 'emphires-addons' ),
				'param_name'	=> 'css',
				'group'			=> esc_attr__( 'Design Options', 'emphires-addons' ),
			)
		)

	);

	return $params;

}

function cspt_vc_pricing_table(){
	return array(
		'name'		=> esc_attr__( 'CreativesPlanet Pricing Table Element', 'emphires-addons' ),
		'base'		=> 'cspt-pricing-table',
		'icon'		=> 'cspt-vc-icon cspt-icon-pricing-table',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_pricing_table_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_pricing_table', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-pricing-table', 'cspt_vc_pricing_table');
}
