<?php

// Add font picker setting to icon box module when you select your font family from the dropdown
if( !function_exists('creativesplanet_vc_add_global_color') ){
function creativesplanet_vc_add_global_color() {

	// Add "Global Color" selector in some VC elements for color selection
	$vc_elements_list = array(
		array(
			'element' => 'vc_icon',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_icon',
			'option'  => 'background_color'
		),
		array(
			'element' => 'vc_toggle',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_tta_tour',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_tta_accordion',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_tta_tabs',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_btn',
			'option'  => 'color'
		),
		array(
			'element' => 'vc_progress_bar',
			'option'  => 'bgcolor'
		),
	);
	foreach( $vc_elements_list as $element ){
		$ele	= $element['element'];
		$option	= $element['option'];
		$param	= WPBMap::getParam( $ele, $option );
		$value	= $param['value'];
		if( is_array($value) ){
			$value													= array_reverse($value);
			$value[ esc_attr__( 'Gradient Color', 'emphires-addons' ) ]		= 'gradientcolor';
			$value[ esc_attr__( 'Secondary Color', 'emphires-addons' ) ]	= 'secondarycolor';
			$value[ esc_attr__( 'Global color', 'emphires-addons' ) ]		= 'globalcolor';
			$param['value']											= array_reverse($value);
			$param['std']											= 'globalcolor';
		}
		vc_update_shortcode_param( $ele, $param );
	}

	// Add Button style
	$param	= WPBMap::getParam( 'vc_btn', 'style' );
	$value	= $param['value'];
	if( is_array($value) ){
		$value[ esc_attr__( 'Simple Link Style', 'emphires-addons' ) ]	= 'simple';
		$param['value']											= $value;
	}
	vc_update_shortcode_param( 'vc_btn', $param );

}
}
add_filter( 'vc_after_init', 'creativesplanet_vc_add_global_color' );

function cspt_responsive_padding_margin_option( $for=''){
	$return = array(
		"type"			=> "creativesplanet_css_editor",
		"heading"		=> esc_attr__("Responsive Padding/Margin Options", "emphires"),
		"description"	=> esc_attr__("You can mange padding/margin from here. For differnt screen sizes", "emphires"),
		"param_name"	=> "cspt_responsive_css",
		'group'			=> esc_attr__( 'Responsive Padding/Margin Options', 'emphires-addons' ),
	);

	if( $for=='column' ){
		$return['break_column_option'] = 'no';
	}

	return $return;
}

/****** Extend VC Elements and add some extra options or modify existing option ******/
if( !function_exists('creativesplanet_vc_add_extra_options') ){
function creativesplanet_vc_add_extra_options(){

	$color_array = array(
		array(
			'label'	=> esc_attr('Default','emphires-addons'),
			'value'	=> '',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-default.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('White','emphires-addons'),
			'value'	=> 'white',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-thumb.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Blackish','emphires-addons'),
			'value'	=> 'blackish',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-thumb.png',
			'width' => 'auto',
		),
	);

	$bgcolor_array = array(
		array(
			'label'	=> esc_attr('Transparent','emphires-addons'),
			'value'	=> 'transparent',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-transparent.png',
			'width'	=> 'auto',
		),
		array(
			'label'	=> esc_attr('White','emphires-addons'),
			'value'	=> 'white',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-white.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Light','emphires-addons'),
			'value'	=> 'light',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-thumb.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Blackish','emphires-addons'),
			'value'	=> 'blackish',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-thumb.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Global Color','emphires-addons'),
			'value'	=> 'globalcolor',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-globalcolor.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Secondary Color','emphires-addons'),
			'value'	=> 'secondarycolor',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-secondarycolor.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Gradient Color','emphires-addons'),
			'value'	=> 'gradientcolor',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/precolor-gradientcolor.png',
			'width' => 'auto',
		),
	);

	$zindex_array = array(
		array(
			'label'	=> esc_attr('Z-Index : 0','emphires-addons'),
			'value'	=> 'zero',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/zindex-1.jpg',
			'width'	=> '150px',
		),
		array(
			'label'	=> esc_attr('Z-Index : 1','emphires-addons'),
			'value'	=> '1',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/zindex-2.jpg',
			'width' => '150px',
		),
		array(
			'label'	=> esc_attr('Z-Index : 2','emphires-addons'),
			'value'	=> '2',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/zindex-3.jpg',
			'width' => '150px',
		),
	);

	$bgimage_position_array = array(
		array(
			'label'	=> esc_attr('Left Top','emphires-addons'),
			'value'	=> '',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-left-top.png',
			'width'	=> 'auto',
		),
		array(
			'label'	=> esc_attr('Left Center','emphires-addons'),
			'value'	=> 'left-center',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-left-center.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Left Bottom','emphires-addons'),
			'value'	=> 'left-bottom',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-left-bottom.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Right Top','emphires-addons'),
			'value'	=> 'right-top',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-right-top.png',
			'width'	=> 'auto',
		),
		array(
			'label'	=> esc_attr('Right Center','emphires-addons'),
			'value'	=> 'right-center',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-right-center.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Right Bottom','emphires-addons'),
			'value'	=> 'right-bottom',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-right-bottom.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Center Top','emphires-addons'),
			'value'	=> 'center-top',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-center-top.png',
			'width'	=> 'auto',
		),
		array(
			'label'	=> esc_attr('Center Center','emphires-addons'),
			'value'	=> 'center-center',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-center-center.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('Center Bottom','emphires-addons'),
			'value'	=> 'center-bottom',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/bgposition-center-bottom.png',
			'width' => 'auto',
		),
	);

	$bgimage_color_order_array = array(
		array(
			'label'	=> esc_attr('BG Color over BG Image','emphires-addons'),
			'value'	=> 'color-over-image',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/color-over-image.png',
			'width' => 'auto',
		),
		array(
			'label'	=> esc_attr('BG Image over BG Color','emphires-addons'),
			'value'	=> 'image-over-color',
			'thumb'	=> EMPHIRES_ADDON_URL . 'images/image-over-color.png',
			'width'	=> 'auto',
		),
	);

	/************* Apply to all ROW and COLUMN elements *******************/

	foreach( array( 'vc_row' , 'vc_column' , 'vc_row_inner' , 'vc_column_inner' ) as $shortcode ){

		// Text Color
		vc_add_param( $shortcode, array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__("Text Color", "emphires"),
			'description'	=> esc_attr__("Select text color.", "emphires"),
			'param_name'	=> 'cspt-text-color',
			'std'			=> '',
			"weight"      	=> 1,
			'value'			=> $color_array,
		));

		// Background Color
		vc_add_param( $shortcode, array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__("Background Color", "emphires"),
			'description'	=> esc_attr__("Select background color.", "emphires"),
			'param_name' 	=> 'cspt-bg-color',
			'std'			=> 'transparent',
			"weight"      	=> 1,
			'value'			=> $bgcolor_array,
		));

		// Z-index
		vc_add_param( $shortcode, array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__( 'Layer position for this ROW (z-index of the ROW)', 'emphires-addons' ),
			'description'	=> esc_attr__( 'Select position for this ROW. Technically this will add z-index css property. So you can overlap ROW on each over by setting this z-index property.', 'emphires-addons' ),
			'param_name'	=> 'cspt-zindex',
			'std'			=> 'zero',
			"weight"      	=> 1,
			'value'			=> $zindex_array,
		));

		// Background image position
		vc_add_param( $shortcode, array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__( 'Background Image Position', 'emphires-addons' ),
			'description'	=> esc_attr__( 'This is useful if you selected background imge for this element.', 'emphires-addons' ),
			'param_name'	=> 'cspt-bg-image-position',
			'std'			=> '',
			"weight"      	=> 1,
			'value'			=> $bgimage_position_array,
		));

		vc_add_param( $shortcode, array(
			'type'			=> 'creativesplanet_imgselector',
			'heading'		=> esc_attr__( 'BG Image - BG Color Order', 'emphires-addons' ),
			'description'	=> esc_attr__( 'You can show BG image over BG Color or reverse too.', 'emphires-addons' ),
			'param_name'	=> 'cspt-bg-image-color-order',
			'std'			=> 'color-over-image',
			"weight"      	=> 1,
			'value'			=> $bgimage_color_order_array,
		));

		// Responsive Padding/Margin Options
		if( $shortcode=='vc_column' || $shortcode=='vc_column_inner' ){
			vc_add_param( $shortcode, array(
				"type"					=> "creativesplanet_css_editor",
				"heading"				=> esc_attr__("Responsive Padding/Margin Options", "emphires"),
				"description"			=> esc_attr__("You can mange padding/margin from here. For differnt screen sizes", "emphires"),
				"param_name"			=> "cspt-responsive-css",
				'group'					=> esc_attr__( 'Responsive Padding/Margin Options', 'emphires-addons' ),
				'break_column_option'	=> 'no',  // We don't need breakpoint in columns
			));
		} else {
			vc_add_param( $shortcode, array(
				"type"			=> "creativesplanet_css_editor",
				"heading"		=> esc_attr__("Responsive Padding/Margin Options", "emphires"),
				"description"	=> esc_attr__("You can mange padding/margin from here. For differnt screen sizes", "emphires"),
				"param_name"	=> "cspt-responsive-css",
				'group'			=> esc_attr__( 'Responsive Padding/Margin Options', 'emphires-addons' ),
			));
		}

	}

	/****** Streched BG *********/
	vc_add_param( 'vc_row', array(
		'type'			=> 'creativesplanet_imgselector',
		"heading"     => esc_html__("Extend Column for background image", "emphires"),
		"description" => esc_html__("Select which column will be extended with background image.", "emphires"),
		'param_name'	=> 'cspt-extended-column',
		'std'			=> '',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'value'			=> array(
			array(
				'label'	=> esc_attr('None','emphires-addons'),
				'value'	=> '',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-none.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('First Column (Left Side Column)','emphires-addons'),
				'value'	=> 'first',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-first.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Last Column (Right Side Column)','emphires-addons'),
				'value'	=> 'last',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-last.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Both Columns (Left and Right Side Column)','emphires-addons'),
				'value'	=> 'both',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-both.png',
				'width'	=> 'auto',
			),
		),
	));
	// VC ROW : First Column BG Image
	vc_add_param( 'vc_row', array(
		'type'			=> 'attach_image',
		'heading'		=> esc_html__( 'First Column BG Image', 'emphires-addons' ),
		'param_name'	=> 'cspt-first-col-bg-image',
		'description'	=> esc_html__( 'Select image.', 'emphires-addons' ),
		"weight"		=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'admin_label'	=> true,
		'edit_field_class'	=> 'vc_col-sm-5 vc_column',
		'dependency'  => array(
			'element'  => 'cspt-extended-column',
			'value'    => array('first','both'),
		),
	));
	// VC ROW: FIRST COLUMN - Background Color
	vc_add_param( 'vc_row', array(
		'type'			=> 'creativesplanet_imgselector',
		'heading'		=> esc_attr__("First Column Background Color", "emphires"),
		'description'	=> esc_attr__("Select background color for first column.", "emphires"),
		'param_name' 	=> 'cspt-first-col-bg-color',
		'std'			=> 'transparent',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'edit_field_class'	=> 'vc_col-sm-7 vc_column',
		'value'			=> $bgcolor_array,
		'dependency'	=> array(
			'element'		=> 'cspt-extended-column',
			'value'			=> array('first','both'),
		),
	));

	// VC ROW : Last Column BG Image
	vc_add_param( 'vc_row', array(
		'type'			=> 'attach_image',
		'heading'		=> esc_html__( 'Last Column BG Image', 'emphires-addons' ),
		'param_name'	=> 'cspt-last-col-bg-image',
		'description'	=> esc_html__( 'Select image.', 'emphires-addons' ),
		"weight"		=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'admin_label'	=> true,
		'edit_field_class'	=> 'vc_col-sm-5 vc_column',
		'dependency'  => array(
			'element'  => 'cspt-extended-column',
			'value'    => array('last','both'),
		),
	));
	// VC ROW: LAST COLUMN - Background Color
	vc_add_param( 'vc_row', array(
		'type'			=> 'creativesplanet_imgselector',
		'heading'		=> esc_attr__("Last Column Background Color", "emphires"),
		'description'	=> esc_attr__("Select background color for last column.", "emphires"),
		'param_name' 	=> 'cspt-last-col-bg-color',
		'std'			=> 'transparent',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'edit_field_class'	=> 'vc_col-sm-7 vc_column',
		'value'			=> $bgcolor_array,
		'dependency'  => array(
			'element'  => 'cspt-extended-column',
			'value'    => array('last','both'),
		),
	));

	// VC ROW : Background Image Position
	vc_add_param( 'vc_row', array(
		"type"			=> "creativesplanet_imgselector",
		"heading"		=> esc_html__("EXTENDED BG: Background Image Position", "emphires"),
		"description"	=> esc_html__("Select Background Image Position for the image selected in", "emphires"),
		"param_name"	=> "cspt-extended-bg-image-position",
		"weight"		=> 1,
		"group"			=> esc_html__('Extended Column','emphires-addons'),
		"value"			=> $bgimage_position_array,
		"std"			=> "center-center",
		'dependency'	=> array(
			'element'		=> 'cspt-extended-column',
			'value'			=> array('first','last','both'),
		),
	));
	// VC ROW : Background Image Repeat
	vc_add_param( 'vc_row', array(
		'type'			=> 'creativesplanet_imgselector',
		"heading"     => esc_html__("EXTENDED BG: Background Image Repeat", "emphires"),
		"description" => esc_html__('This option sets if/how a background image will be repeated.', 'emphires-addons') . ' <a href="https://www.w3schools.com/cssref/playit.asp?filename=playcss_background-repeat&preval=space" target="_blank">'.esc_attr('See example here', 'emphires-addons').'</a>',
		"param_name"  => "cspt-extended-bg-image-repeat",
		'std'			=> '',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'dependency'	=> array(
			'element'		=> 'cspt-extended-column',
			'value'			=> array('first','last','both'),
		),
		'value'			=> array(
			array(
				'label'	=> esc_attr('Repeat (Default)','emphires-addons'),
				'value'	=> '',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Horizontal Repeat (repeat-x)','emphires-addons'),
				'value'	=> 'x',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-x.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Vertical Repeat (repeat-y)','emphires-addons'),
				'value'	=> 'y',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-y.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('No Repeat (no-repeat)','emphires-addons'),
				'value'	=> 'no',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-no-repeat.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Repeated and/or extended (round)','emphires-addons'),
				'value'	=> 'round',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-round.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Repeated and/or extended with spacing (space)','emphires-addons'),
				'value'	=> 'space',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-space.png',
				'width'	=> 'auto',
			),

		),
	));

	vc_add_param( 'vc_row', array(
		'type'			=> 'creativesplanet_imgselector',
		"heading"     => esc_html__("EXTENDED BG: Background Image Size", "emphires"),
		"description" => esc_html__('Set CSS property for background-size using this option.', 'emphires-addons') . ' <a href="https://www.w3schools.com/cssref/playit.asp?filename=playcss_background-repeat&preval=space" target="_blank">'.esc_attr('See example here', 'emphires-addons').'</a>',
		"param_name"  => "cspt-extended-bg-size",
		'std'			=> '',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'dependency'	=> array(
			'element'		=> 'cspt-extended-column',
			'value'			=> array('first','last','both'),
		),
		'value'			=> array(
			array(
				'label'	=> esc_attr('Default (auto)','emphires-addons'),
				'value'	=> '',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Cover','emphires-addons'),
				'value'	=> 'cover',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-x.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Contain','emphires-addons'),
				'value'	=> 'contain',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/bg-repeat-y.png',
				'width'	=> 'auto',
			),

		),
	));

	// VC COLUMN : Stretched BG
	vc_add_param( 'vc_column', array(
		'type'			=> 'creativesplanet_imgselector',
		"heading"     => esc_html__("Extend Column for background image", "emphires"),
		"description" => esc_html__("Select which column will be extended with background image.", "emphires"),
		'param_name'	=> 'cspt-extended-column',
		'std'			=> '',
		"weight"      	=> 1,
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'value'			=> array(
			array(
				'label'	=> esc_attr('None','emphires-addons'),
				'value'	=> '',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-none.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Left Side Stretched','emphires-addons'),
				'value'	=> 'left',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-first.png',
				'width'	=> 'auto',
			),
			array(
				'label'	=> esc_attr('Right Side Stretched','emphires-addons'),
				'value'	=> 'right',
				'thumb'	=> EMPHIRES_ADDON_URL . 'images/extended-bg-last.png',
				'width'	=> 'auto',
			),
		),
	));

	vc_add_param( 'vc_column', array(
		'type'			=> 'dropdown',
		'heading'		=> __( 'Also stretch content too?', 'emphires-addons' ),
		'param_name'	=> 'cspt-strech-content',
		'description'	=> __( 'Also stretch content too?', 'emphires-addons' ),
		'value'			=> array(
			esc_attr__('No', 'emphires-addons')		=> '',
			esc_attr__('Yes', 'emphires-addons')	=> 'yes',
		),
		'std'			=> '',
		"group"		  => esc_html__('Extended Column','emphires-addons'),
		'dependency'	=> array(
			'element'		=> 'cspt-extended-column',
			'value'			=> array( 'left', 'right' ),
		),
	));

}
}
add_action( 'vc_after_init', 'creativesplanet_vc_add_extra_options', 21 );

if( !function_exists('creativesplanet_vc_add_gfonts') ){
function creativesplanet_vc_add_gfonts( $list ){
	$list = array_reverse($list);

	// Font: Montserrat
	// Removed if already exists
	foreach( $list as $key=>$val ){
		if( !empty($val->font_family) && $val->font_family == 'Montserrat' ){
			unset( $list[$key] );
		}
	}
	// Now creating list with font properties
	$Montserrat->font_family = esc_attr('Montserrat');
	$Montserrat->font_styles = "100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i";
	$Montserrat->font_types = "100 Thin:100:normal,100 Thin Italic:100:normal,200 Extra-Light:200:normal,200 Extra-light Italic:200:italic,300 Light:300:normal,300 Light Italic:300:italic,400 Regular:400:normal,400 Regular Italic:400:italic,500 Medium:500:normal,500 Medium Italic:500:italic,600 Semi-bold:600:normal,600 Semi-bold Italic:600:italic,700 Bold:700:normal,700 Bold Italic:700:italic,800 Extra-bold:800:normal,800 Extra-bold Italic:800:italic,900 Black:900:normal,900 Black Italic:900:italic";
	$list[] = $Montserrat;

	// Font: Muli
	// Removed if already exists
	foreach( $list as $key=>$val ){
		if( !empty($val->font_family) && $val->font_family == 'Muli' ){
			unset( $list[$key] );
		}
	}
	// Now creating list with font properties
	$Muli->font_family = esc_attr('Muli');
	$Muli->font_styles = "200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i";
	$Muli->font_types = "200 Extra-Light:200:normal,200 Extra-light Italic:200:italic,300 Light:300:normal,300 Light Italic:300:italic,400 Regular:400:normal,400 Regular Italic:400:italic,500 Medium:500:normal,500 Medium Italic:500:italic,600 Semi-bold:600:normal,600 Semi-bold Italic:600:italic,700 Bold:700:normal,700 Bold Italic:700:italic,800 Extra-bold:800:normal,800 Extra-bold Italic:800:italic,900 Black:900:normal,900 Black Italic:900:italic";
	$list[] = $Muli;

	// Font: Poppins
	// Removed if already exists
	foreach( $list as $key=>$val ){
		if( !empty($val->font_family) && $val->font_family == 'Poppins' ){
			unset( $list[$key] );
		}
	}
	// Now creating list with font properties
	$Poppins->font_family = esc_attr('Poppins');
	$Poppins->font_styles = "100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i";
	$Poppins->font_types = "100 Thin:100:normal,100 Thin Italic:100:normal,200 Extra-Light:200:normal,200 Extra-light Italic:200:italic,300 Light:300:normal,300 Light Italic:300:italic,400 Regular:400:normal,400 Regular Italic:400:italic,500 Medium:500:normal,500 Medium Italic:500:italic,600 Semi-bold:600:normal,600 Semi-bold Italic:600:italic,700 Bold:700:normal,700 Bold Italic:700:italic,800 Extra-bold:800:normal,800 Extra-bold Italic:800:italic,900 Black:900:normal,900 Black Italic:900:italic";
	$list[] = $Poppins;

	// again reverse
	$list = array_reverse($list);

	// Return list
	return $list;
}
}
add_filter('vc_google_fonts_get_fonts_filter', 'creativesplanet_vc_add_gfonts');