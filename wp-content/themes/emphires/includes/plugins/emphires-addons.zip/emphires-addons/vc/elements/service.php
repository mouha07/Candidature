<?php

if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

// Generating VC element
function cspt_vc_service_params(){

	$heading_options = cspt_vc_heading_params( 'h_' , 'Title Settings' );

	// Default titles
	$cpt_singular_title	= esc_attr__('Service','emphires-addons');
	if( class_exists('Kirki') ){
		// Dynamic Name
		$cpt_singular_title2	= Kirki::get_option( 'service-cpt-singular-title' );
		$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;
	}

	$params = array_merge(

		$heading_options,

		array(
			array(
				'type'			=> 'creativesplanet_imgselector',
				'heading'		=> sprintf( esc_attr__( '%1$s View Style', 'emphires-addons' ) , $cpt_singular_title ) ,
				'description'	=> esc_attr__( 'Select Service view style.', 'emphires-addons' ),
				'param_name'	=> 'style',
				'std'			=> '1',
				'value'			=> cspt_element_template_list('service', true),
				'group'			=> esc_attr__( 'View Style', 'emphires-addons' ),
			),
		),

		array(
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_attr__( '"More" text', 'emphires-addons' ),
				'param_name'	=> 'more_text',
				'description'	=> esc_attr__( 'Change the "Read More" link text.', 'emphires-addons' ),
				'group'			=> esc_attr__( 'Content Options', 'emphires-addons' ),
				'std'			=> esc_attr__( 'More', 'emphires-addons' ),
			)
		),

		cspt_vc_box_element_content_params( 'service' )

	);

	return $params;

}

function cspt_vc_service(){

	// Default titles
	$cpt_singular_title	= esc_attr__('Service','emphires-addons');
	if( class_exists('Kirki') ){
		// Dynamic Name
		$cpt_singular_title2	= Kirki::get_option( 'service-cpt-singular-title' );
		$cpt_singular_title		= ( !empty($cpt_singular_title2) ) ? $cpt_singular_title2 : $cpt_singular_title ;
	}

	return array(
		'name'		=> sprintf( esc_attr__( 'CreativesPlanet %1$s Element', 'emphires-addons' ) , $cpt_singular_title ) ,
		'base'		=> 'cspt-service',
		'icon'		=> 'cspt-vc-icon cspt-icon-service',
		'category'	=> array( esc_attr__( 'EMPHIRES ELEMENTS', 'emphires-addons' ) ),
		'params'	=> cspt_vc_service_params(),
	);
}
//add_action( 'vc_after_init', 'cspt_vc_service', 25 );
if( function_exists('vc_lean_map') ){
	vc_lean_map('cspt-service', 'cspt_vc_service');
}

